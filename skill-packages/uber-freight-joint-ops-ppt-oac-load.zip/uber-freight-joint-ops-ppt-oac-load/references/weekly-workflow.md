# Weekly Workflow

## Source and OAC workflow

### Run dates

Use America/New_York local time. Define the following once at run start.

- `run_date`: local date in `YYYY-MM-DD`.
- `target_week`: native Excel `week` date from the completed Data Extract. Render as `YYYY-MM-DD` only in verification reports.
- `file_date`: `run_date` in `MM.DD.YY`.
- `deck_date`: next local calendar date after `run_date`, in `MM_DD_YY`.
- `deck_written_date`: `deck_date` in `Month DayOrdinal, Year`.

`deck_date` controls only the target deck filename and Slide 1 meeting date. Source, OAC, table, and WoW dates come from verified source records.

### Week-date contract

Use this contract for every populated `week` cell in `Compute`, `Block-Storage`, `Object-Storage`, `FastConnect`, `IPsec`, and `NAT-GW`.

- Report dates as `YYYY-MM-DD`, but do not apply that custom format to workbook cells.
- Store each value as a native numeric Excel date serial. Under General, the cell must display a number, never text or blank.
- Preserve the workbook's built-in Excel Short Date style. In OOXML, the cell's style must resolve to built-in `numFmtId` `14` with `applyNumberFormat="1"`.
- Append rows inside the existing Table so the `week` cell inherits the preceding row's style. Do not apply a custom mask such as `yyyy-mm-dd` or `m/d/yy;@`.
- Use the direct Office download of the verified SharePoint workbook for the dated local upload. Do not save, export, convert, or rebuild the dated upload with a spreadsheet library, CSV pipeline, or non-Excel utility. Preserve the original XLSX package and its styles, relationships, and metadata.
- A visible date is insufficient evidence. The local-file gate must prove both the native serial and built-in Short Date style before OAC sees the file.

### Fixed locations

- Source workbook: <https://oracle.sharepoint.com/:x:/r/teams/SceCloudNative/Shared%20Documents/Customers/Uber/Uber%20Freight/Uber%20Freight%20Joint%20Ops/UF%20Joint%20Ops%20-%20CSVs%20for%20OAC/UF-Joint-Ops_OAC.xlsx?d=w93c9059e33b149a4a2786eedb03e1cf0&csf=1&web=1&e=cQEF84>
- Local download folder: `C:\Users\Michael Sheerin\OneDrive - Oracle Corporation\..FY27\Uber\Freight Joint Ops\OAC Upload Data`
- OAC catalog: <https://ubertest-id4mfodfhzzk-16-ia.analytics.ocp.oraclecloud.com/ui/dv/?pageid=catalog#>
- OAC dashboard: <https://ubertest-id4mfodfhzzk-16-ia.analytics.ocp.oraclecloud.com/ui/dv/?pageid=visualAnalyzer&reportmode=full&reportpath=%2F%40Catalog%2Fshared%2FUF%20Joint%20Ops%2FUF%20Joint%20Ops%20-%20Usage%20Trends%20-%20v5>
- SharePoint PowerPoint folder: <https://oracle.sharepoint.com/:f:/r/teams/SceCloudNative/Shared%20Documents/Customers/Uber/Uber%20Freight/Uber%20Freight%20Joint%20Ops?d=w02e3edc6ae944a5f9a15400c0af495c7&csf=1&web=1&e=sCkaIZ>

### Source workbook gate

Open the source workbook in Excel for the web. Confirm the original `UF-Joint-Ops_OAC.xlsx` sits in the specified folder. Inspect `Compute`, `Block-Storage`, `Object-Storage`, `FastConnect`, `IPsec`, and `NAT-GW`.

For each worksheet, record the newest and immediately prior distinct populated `week`, record counts, and natural keys. The newest complete date must equal `target_week`. Never derive the prior source date by subtracting seven days. Latest `week` cells must meet the Week-date contract.

| Worksheet | Newest-date records | Required keys |
| --- | ---: | --- |
| Compute | 6 | PHX and IAD, each with AD-1, AD-2, AD-3 |
| Block-Storage | 2 | PHX and IAD |
| Object-Storage | 2 | PHX and IAD |
| FastConnect | 2 | PHX and IAD |
| IPsec | 4 | PHX and IAD, each with Ingress and Egress |
| NAT-GW | 4 | PHX and IAD, each with Ingress and Egress |

Verify all newest-date metrics are numeric. Reject unit labels, percent signs, `K`, `M`, `Mil`, `No data`, blanks, and placeholders. Reject duplicate natural keys. Verify FastConnect `max_utilization` stores a decimal fraction, such as `0.0334` for a displayed `3.34%`. `FastConnect!is_phx` is a required upstream numeric attribute: every PHX row equals `1` and every IAD row equals `0` for the newest and prior complete dates. The Data Extract workflow owns this field. A routine load stops if the field is absent or inconsistent and never writes or derives it. Verify new records sit within the existing Excel Table or contiguous OAC source range.

Audit the actual populated-cell boundary, not Excel's displayed used range alone. Every nonblank cell must fall inside the expected table or source range. Reject cells outside the range, including hidden rows, columns, or stray values far below the table. A prior Compute fault placed values in `F884844:F884845`, which extended the workbook range and contaminated the OAC cache. Confirm `Saved` or `Last saved` only after this boundary audit passes.

On failure, stop and report the worksheet, newest and prior dates, expected and observed count, and failed field, key, range, or date type.

### Download and local-file gate

Download only after the source gate passes. Save as `UF-Joint-Ops_OAC_<file_date>.xlsx` in the fixed local folder. If the same dated local file exists, replace only that file after the source gate passes. Use the direct Office download and do not open-and-save, export, or transform the downloaded file before OAC reload.

Reopen the local workbook and reverify every worksheet, date, count, key, native Date, metric value, and source range against the verified SharePoint workbook. Then complete the local date preflight:

1. Confirm every populated `week` cell in all six sheets has a numeric serial under General and no blanks.
2. Confirm all newest-date records equal `target_week` and every `week` cell retains the existing built-in Short Date style.
3. Confirm the new rows are inside their existing Tables and the `week` header remains exactly `week`.
4. Reject files with text dates, a custom date mask, a missing or empty date-format mask, a rebuilt style table, or a generic-exported XLSX package.

Reject stale cached source ranges and failed date preflight. Do not select a failed file in OAC.

### OAC dataset gate

In `Shared Folders` > `UF Joint Ops`, rebind and reload each existing dataset, one at a time, from `UF-Joint-Ops_OAC_<file_date>.xlsx`:

- `UF_Compute`
- `UF_Block`
- `UF_Object`
- `UF_FastConnect`
- `UF_IPsec`
- `UF_NATGW`

For each dataset, open `Edit Definition`, select the dated workbook, and explicitly select its mapped worksheet. OAC defaults a new workbook selection to `Compute`, so never rely on the prior sheet setting. Run `Refresh Data`, select header `OK`, select the global dataset Save glyph, wait for `Save successfully completed.`, then select `Refresh Profile Results`. Do this even when the Results grid already shows the current rows, because OAC retains stale source-query cache state behind a current-looking preview. In Results, verify:

- `week` has Data Type `Date`, Treat As `Attribute`, and Aggregation `None`.
- Metric fields have Data Type `Number`.
- In `UF_FastConnect`, `is_phx` has Data Type `Number`, Treat As `Attribute`, and Aggregation `None`.
- Newest date and newest-date count match the verified source workbook.
- No duplicate natural key exists.

Treat reload counters as full-dataset counters only. Use Results for newest-date checks. If OAC reports `expected: varchar, actual: date`, retain native Excel Dates and correct the OAC field definition to Date. Never convert workbook dates to text.

If OAC reports `invalid [formatmask] for column: week` with `actual: <empty>`, stop the reload. Do not retry the same file or change the OAC field type. The local file failed the Week-date contract. Create a fresh dated download from the verified SharePoint workbook. If a fresh download still fails, use the latest OAC-successful dated workbook only as a structural Excel baseline, append or update the current rows inside its existing Tables using Excel, preserve its existing built-in Short Date styles and package metadata, rerun the local date preflight, then retry the affected dataset once.

For `UF_NATGW`, retain direct native-Date input. Its preparation script contains only the workbook source step and `Results`. Do not add `Convert to Text`, `Convert to Date`, `Extract Day`, `Extract Day of Month`, or any other `week` transform.

If a reload or save fails, retain the exact error. Reopen only the failed dataset, verify the dated file, existing mapping, exact selected worksheet, and existing range, then retry once. If retry fails, record the dataset and error. Do not validate OAC canvases or edit the deck until all six datasets pass.

### OAC workbook gate

After all dataset reloads, select the dashboard `Refresh Data` control and wait for every visual to finish. Then open `Shared Folders` > `UF Joint Ops` > `UF Joint Ops - Usage Trends - v4` in a fresh browser page. Inspect:

- `Compute - PHX`, `Compute - IAD`
- `Block Storage - PHX`, `Block Storage - IAD`
- `Object Storage - PHX`, `Object Storage - IAD`
- `FastConnect - PHX`, `FastConnect - IAD`
- `IPsec - PHX`, `IPsec - IAD`
- `NAT-GW - PHX`, `NAT-GW - IAD`

For every canvas, wait for all visuals. Reject `No Data Found`, query error, reload failure, indefinite loading, duplicate newest-date series, or unexpected blank categories. Verify the newest plotted date and displayed region, direction, and metric values against the reloaded source.

### Dashboard cache recovery

If Results shows the current rows but any canvas shows `No Data Found`, rebind only the dataset behind the failed canvas using this fixed sequence: `Edit Definition` > select the verified dated workbook > select the exact mapped worksheet > `Refresh Data` > header `OK` > global dataset Save glyph > wait for `Save successfully completed.` > `Refresh Profile Results`. Select dashboard `Refresh Data`, open a fresh dashboard page, and rerun the complete 12-canvas validation. Repeat this recovery once per failed dataset.

For `FastConnect - PHX`, replace `region = PHX` with `is_phx = 1` in the existing visual only if all evidence below holds after the recovery sequence:

- `UF_FastConnect` Results shows newest PHX and IAD rows with valid numeric `is_phx` values.
- `FastConnect - IAD` works.
- Clearing `region = PHX` shows data, and restoring it shows `No Data Found`.

Preserve the base `week` axis, existing measures, title, layout, formatting, and styling. Do not alter `FastConnect - IAD`. Save the OAC workbook, select dashboard `Refresh Data`, open a fresh page, and rerun all twelve canvas checks. If this repair does not resolve the PHX canvas, or if another canvas still fails, record the failed canvas, dataset, source boundary audit, exact OAC error, and Results newest-date row. Do not start deck edits.

For FastConnect, use the numeric fraction field with percentage display formatting. Do not multiply values by 100 or add a calculation. For IPsec and NAT-GW, verify the X-axis uses base `week` with chronological date or month labels. Reject labels limited to `1` through `31`. On rejection, verify native workbook Dates and OAC Date metadata, save the dataset, then refresh the browser page. Outside the documented FastConnect PHX repair, do not edit dashboard filters, fields, axes, formulas, titles, layouts, or styles.

## PowerPoint table workflow

### Target deck and Slide 1

Use the SharePoint folder above. Target filename: `MM_DD_YY_Uber_Freight_Weekly_Joint Ops.pptx`, using `deck_date`.

If the target exists, update it in place. If absent, select the latest valid earlier weekly deck by filename date prefix, duplicate it in the same folder, and rename the duplicate with `deck_date`. Never select by modified date. Never alter the source deck.

Update only Slide 1's visible meeting date to `deck_written_date`, for example `September 9th, 2026`. Use correct ordinal suffixes, including `11th`, `12th`, and `13th`. Preserve every visual property, including ordinal superscript styling.

### Source and table rules

The source workbook is the sole weekly data source. For each Excel tab, select the newest distinct `week` with its full expected key set as `current_week`; select the immediately earlier distinct complete `week` as `prior_week`. Use one date pair for every mapped row in each tab.

Before editing, add a reconciliation row for each PowerPoint cell: slide, Excel tab, region, AD or direction, metric, current raw value, prior raw value, calculated WoW, and display value. Stop if a required source dimension, metric, or date is missing.

Edit individual table cell text only. Do not change a table's dimensions, placement, row height, column width, merge state, font, fill, border, alignment, text styling, unit spacing, or layout. Update only current and prior date headers, current and prior values, and WoW cells. Format table dates as `MM/DD/YY`.

### Values and WoW

Calculate from unrounded source values: `WoW % = ((Current Week - Prior Week) / Prior Week) × 100`. First derive current and prior values, then calculate WoW. Show WoW to two decimals with `+` or `-`; show zero as `0.00%`. Show `0.00%` where both values equal zero. Show `N/A` where prior equals zero and current is nonzero.

For non-IPsec and non-NAT-GW data values, retain the existing number style and unit. Round fractions to two decimals. When a nonzero source value would show as `0.00`, retain enough decimals to show a nonzero value.

For all non-percent IPsec and NAT-GW telemetry values on slides 25, 27, 29, and 31, round to nearest `0.001` before display. Retain the existing unit, comma style, and whole-number style. Show three decimals when the rounded value has a fraction. `0.001768` shows `0.002`; `0.002501` shows `0.003`; `0.002070` shows `0.002`. Preserve the existing zero format. If a nonzero value rounds to `0.000`, show signed `0.001` or `-0.001`. Calculate WoW from unrounded values.

| Slide | Excel tab | Filter | Required values |
| ---: | --- | --- | --- |
| 7 | Compute | PHX | Instances, OCPUs, Memory (GB), each listed AD |
| 9 | Compute | IAD | Instances, OCPUs, Memory (GB), each listed AD |
| 12 | Block-Storage | PHX | Boot Volume, Data Volume, Total Volume, Boot TB, Data TB, Total TB |
| 14 | Block-Storage | IAD | Boot Volume, Data Volume, Total Volume, Boot TB, Data TB, Total TB |
| 16 | Object-Storage | PHX | Buckets and TB, source GB divided by 1,000 |
| 18 | Object-Storage | IAD | Buckets and GB, retain source storage unit |
| 21 | FastConnect | PHX | Avg Bandwidth, Max Bandwidth, Max Utilization; bandwidth Mbps divided by 1,000 |
| 23 | FastConnect | IAD | Avg Bandwidth, Max Bandwidth, Max Utilization; bandwidth Mbps divided by 1,000 |
| 25 | IPsec | PHX | Ingress Avg, Ingress Max, Egress Avg, Egress Max Bandwidth |
| 27 | IPsec | IAD | Ingress Avg, Ingress Max, Egress Avg, Egress Max Bandwidth |
| 29 | NAT-GW | PHX | Ingress/Egress Max Throughput, Max Packets, Max Packet Drops |
| 31 | NAT-GW | IAD | Ingress/Egress Max Throughput, Max Packets, Max Packet Drops |

For slides 12 and 14, use only an equation supported by available source values: `Data Volume = Total Volume - Boot Volume`, `Total Volume = Boot Volume + Data Volume`, `Data TB = Total TB - Boot TB`, and `Total TB = Boot TB + Data TB`.

Before saving, verify target filename, Slide 1 date, all headers, mappings, units, Object Storage IAD GB, FastConnect fractional percentages, unrounded WoW, IPsec/NAT-GW rounding, nonzero display, unchanged source workbook/deck, deck openability, and SharePoint save state. Report target name and folder, source deck, current/prior date per tab, and all updated table slides.

## Screenshot workflow

Update the same target deck. Open the OAC dashboard from the fixed URL. Capture the verified saved dashboard state. Retain all dashboard filters, prompts, calculations, selected dates, titles, legends, axes, sort order, and canvas settings, including the documented FastConnect PHX repair if performed. Set browser zoom to 100 percent and use native rendering scale. Do not use generated, edited, recreated, annotated, enhanced, cropped, or resampled images.

For each canvas, confirm its name, wait for every visual and the rightmost newest date, then capture the full native OAC viewport. Include the dark title bar, `Click here to add a filter` row, complete canvas, all charts and axes, and bottom canvas-tab strip. Exclude browser chrome, taskbar, modals, tooltips, and cursor. Reject missing rightmost dates, clipped axes, blurred text, white borders, or wrong-canvas content.

| Slide | Slide header | OAC canvas |
| ---: | --- | --- |
| 8 | Running Instances (PHX) | Compute - PHX |
| 10 | Running Instances (IAD) | Compute - IAD |
| 13 | Block Storage Utilization (PHX) | Block Storage - PHX |
| 15 | Block Storage Utilization (IAD) | Block Storage - IAD |
| 17 | Object Storage Utilization (PHX) | Object Storage - PHX |
| 19 | Object Storage Utilization (IAD) | Object Storage - IAD |
| 22 | FastConnect Telemetry (PHX) | FastConnect - PHX |
| 24 | FastConnect Telemetry (IAD) | FastConnect - IAD |
| 26 | IPsec Telemetry (PHX) | IPsec - PHX |
| 28 | IPsec Telemetry (IAD) | IPsec - IAD |
| 30 | NAT Gateway Telemetry (PHX) | NAT-GW - PHX |
| 32 | NAT Gateway Telemetry (IAD) | NAT-GW - IAD |

Before each replacement, confirm the target slide header and prepare the verified capture. Remove only the prior dashboard screenshot object. Place the capture at full available width directly below the orange or blue top border. Preserve native aspect ratio. Do not crop, stretch, downscale, add side whitespace, or add decorations. Bring the existing slide title to front. Verify the title and new screenshot are the only visible changes.

Before saving, verify all 12 mappings, full viewport contents, content-edge alignment, source aspect ratio, rightmost date, outer axes, clear chart text, title layering, unaltered deck structure, deck openability, and SharePoint save state. If access, canvas, chart load, mapping, target deck, or replacement-area validation fails, stop without saving a partial output. Report the deck filename and folder, all updated screenshot slides, and SharePoint save confirmation.
