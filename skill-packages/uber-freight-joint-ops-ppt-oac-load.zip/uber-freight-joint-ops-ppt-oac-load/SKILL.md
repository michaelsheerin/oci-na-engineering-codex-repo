---
name: uber-freight-joint-ops-ppt-oac-load
description: "Run the post-extract Uber Freight Joint Ops workflow: verify the SharePoint source workbook, reload six OAC datasets, validate OAC canvases, and update the weekly PowerPoint tables and dashboard screenshots. Use after the weekly Data Extract succeeds."
---

# Uber Freight Joint Ops Ppt Oac Load

Run this workflow only after the weekly Data Extract has completed, the SharePoint workbook reports a successful save, and no source-data conflict exists. Do not use this skill for data extraction, routine source-workbook editing, OAC model changes, dashboard redesign, or PowerPoint redesign. The reference defines the sole evidence-gated dashboard repair.

Read [the full workflow](references/weekly-workflow.md) before acting. It defines URLs, field checks, mappings, calculations, slide rules, save gates, and reports.

## Date compatibility

`week` is an OAC date field. The dated upload workbook must preserve native Excel date serials and the original workbook package. Use the direct Office download from the verified SharePoint workbook. Do not save, export, convert, or rebuild the dated upload through a spreadsheet library or another non-Excel tool. Such steps can remove the `week` format mask even when dates display correctly.

## Operating model

1. Use America/New_York time. Set `run_date`, `target_week`, `file_date`, `deck_date`, and `deck_written_date` once at run start. Do not recompute them.
2. Use the active authenticated SharePoint and OAC sessions. If sign-in, MFA, account selection, access approval, or permission action needs user input, stop with `Action required: <site and exact action>. Complete the action, then reply complete.` Resume at the interrupted step after `complete`.
3. Keep one in-memory reconciliation manifest from source verification through PowerPoint save. Per service, record source dates, expected keys, raw values, derived values, display values, OAC result, and target slide or canvas.
4. Treat each gate as a dependency boundary. Do not proceed past a failed gate. Do not repeat a completed verification, reload, or slide update unless an authentication interruption invalidates it.

## Required phase order

1. Verify the six source workbook worksheets and their newest complete `week` records.
2. Download the verified workbook under the dated filename, then reverify the local file and its `week` date contract.
3. Rebind, reload, save, profile-refresh, and validate all six existing OAC datasets, one at a time. Explicitly select the mapped worksheet after every source-file selection.
4. Select dashboard `Refresh Data`, then open a fresh OAC dashboard page and validate every mapped workbook canvas.
5. Update the one target PowerPoint's data tables, preserving all structure and user edits.
6. Replace the target deck's mapped dashboard screenshots with native full-viewport captures.
7. Complete the relevant quality gate, verify the SharePoint save state, and report the required outputs.

## Non-negotiable boundaries

- Treat `UF-Joint-Ops_OAC.xlsx` as the only weekly data source. Use calculated Excel values, never formula text or an older deck, dashboard, or screenshot.
- Treat `YYYY-MM-DD` as report notation only. In the upload workbook, every populated `week` cell must be a numeric Excel serial styled with the existing built-in Short Date format, never a text date or custom date mask.
- Do not edit the SharePoint source workbook or alter its formulas, tables, values, formats, rows, ranges, or metadata during a routine load. `FastConnect!is_phx` is an upstream Data Extract field and must be numeric, with `1` for PHX and `0` for IAD. Stop if that condition fails.
- Do not create, delete, rename, replace, or redesign OAC datasets or workbooks. Retain ranges, fields, filters, calculations, layouts, and styles. Rebind an existing dataset only to the verified dated workbook and its explicitly selected worksheet mapping. The reference permits one FastConnect PHX filter substitution only after its evidence gate passes.
- Use one target deck per `deck_date`. Update an existing target deck in place. When absent, duplicate the latest valid prior deck selected by filename date prefix. Do not replace an existing target with a local download.
- Preserve all target-deck user edits. Change only the required table cell text and prior dashboard screenshot object. Verify `Saved` or `Last saved` after every PowerPoint edit stage.
- Stop before a dependent write after any required source, OAC, dashboard, deck, or screenshot check fails. Report the exact failed item and observed result.

## Reference routing

- Read [Source and OAC workflow](references/weekly-workflow.md#source-and-oac-workflow) for dates, source checks, local download, dataset reloads, and canvas validation.
- Read [PowerPoint table workflow](references/weekly-workflow.md#powerpoint-table-workflow) before editing Slide 1 or any table.
- Read [Screenshot workflow](references/weekly-workflow.md#screenshot-workflow) before capturing or replacing dashboard images.
