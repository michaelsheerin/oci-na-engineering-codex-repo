---
name: sr-access
description: Use when you need to access Oracle Service Request (SR) details from this local SR thing workspace using the provided SR scripts and credentials.
---

# SR Access

Use this skill only for Oracle Service Request (SR) access and SR data handling in this workspace.

## How We Access SRs

SRs are accessed through Oracle Fusion Service REST APIs using the local script:

```bash
python scripts/fetch_sr_details.py --env .env --sr-list inputs/sr_numbers.txt --output outputs/sr_details.json
```

The script reads SR numbers from a text file, one SR number per line, and writes the fetched details to a JSON output file.

Each teammate must create their own local `.env` file from `.env.example` and put their own bearer token there before running the scripts. Do not share a filled-in `.env`.

Required `.env` values:

```dotenv
SR_BASE_URL=https://fa-etmi-saasfaprod1.fa.ocs.oraclecloud.com
SR_BEARER_TOKEN=<token>
```

Instead of `SR_BEARER_TOKEN`, the full authorization header can be provided as:

```dotenv
SR_AUTH_HEADER=Bearer <token>
```

Optional `.env` override:

```dotenv
SR_RESOURCE_PATH=/crmRestApi/resources/latest/serviceRequests
```

The script tries the configured service request resource path and compatible Oracle REST service request paths. SR access requires VPN connectivity, a valid token, and API entitlement for the service request REST resource.

## Workflow

1. Put the requested SR numbers in a text file, one per line.
2. Copy `.env.example` to `.env`, then fill in `SR_BEARER_TOKEN` with your bearer token. `SR_AUTH_HEADER=Bearer <token>` also works if you prefer the full header form.
3. Run `scripts/fetch_sr_details.py` with `--env`, `--sr-list`, and `--output`.
4. Use the generated JSON rows for analysis, reporting, or workbook updates.

## Sharing Hygiene

- Keep `.env`, generated workbooks, output JSON, and cache files local.
- Do not commit or share real OCIDs, bearer tokens, private keys, or copied browser authorization headers.
- If a script needs one-off OCID reason overrides, add them locally before running and remove them before sharing.

## Output Fields

The SR fetch script writes rows with these fields when available:

- `SR`
- `SRHeading`
- `CreationDate`
- `LastUpdateDate`
- `IssueDescription`
- `Severity`
- `Status`
- `CreatedBy`
- `SROwner`

Keep responses grounded in the fetched SR data or files provided in this workspace.
