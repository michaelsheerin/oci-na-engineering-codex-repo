import argparse
import json
import re
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path


CURRENT_DATE = datetime(2026, 7, 23, tzinfo=timezone.utc)


def parse_date(value):
    if not value:
        return None
    text = str(value).strip()
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        parsed = datetime.fromisoformat(text)
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed


def compact(value):
    return re.sub(r"\s+", " ", str(value or "")).strip()


def combined_text(row):
    return f"{compact(row.get('SRHeading'))} {compact(row.get('IssueDescription'))}".lower()


def classify(row):
    text = combined_text(row)
    title = compact(row.get("SRHeading")).lower()

    rules = [
        ("Documentation", r"\b(documentation|document|doc update|doc bug|runbook|steps unclear|guide)\b"),
        ("Upgrade / Maintenance / Patching", r"\b(upgrade|patch|patching|maintenance|version|image|release|rollback)\b"),
        ("Setup / Configuration", r"\b(setup|configuration|configure|config|onboarding|provision|install|setting|policy|permission|auth|certificate|cert)\b"),
        ("Customization / Integration", r"\b(custom|integration|integrat|api|webhook|connector|automation|terraform|script|oci cli|plugin)\b"),
        ("Operations / IT Help", r"\b(how to|request|access|capacity|quota|limit|help|question|assist|operational|procedure|status|monitor|metric)\b"),
        ("Product Defects", r"\b(defect|bug|known issue|regression|code fix|product issue|fix available|workaround|not working as expected)\b"),
        ("Break Fix / Functional Errors", r"\b(error|failed|failure|broken|unable|cannot|can't|issue|problem|down|stuck|timeout|exception|crash|not working|unavailable)\b"),
    ]

    for category, pattern in rules:
        if re.search(pattern, text):
            return category

    if any(token in title for token in ("sr", "issue", "unable", "failed")):
        return "Break Fix / Functional Errors"
    return "Other"


def sentiment(row):
    text = combined_text(row)
    negative = [
        "critical",
        "urgent",
        "business impact",
        "production",
        "down",
        "blocked",
        "unable",
        "failed",
        "failure",
        "stuck",
        "escalat",
        "sev1",
        "sev 1",
    ]
    if any(term in text for term in negative):
        return "Concerned / urgent"
    return "Neutral / informational"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--details", default="../outputs/sr_details.json")
    args = parser.parse_args()

    path = Path(args.details)
    payload = json.loads(path.read_text(encoding="utf-8"))
    rows = payload["rows"]
    errors = payload.get("errors", [])

    status_counts = Counter(compact(row.get("Status")) or "Unknown" for row in rows)
    severity_counts = Counter(compact(row.get("Severity")) or "Unknown" for row in rows)
    closed_rows = [row for row in rows if compact(row.get("Status")).lower() in {"resolved", "closed"}]
    open_rows = [row for row in rows if row not in closed_rows]

    update_diffs = []
    open_ages = []
    for row in rows:
        created = parse_date(row.get("CreationDate"))
        updated = parse_date(row.get("LastUpdateDate"))
        if created and updated:
            update_diffs.append((updated - created).total_seconds() / 86400)
        if row in open_rows and created:
            open_ages.append((CURRENT_DATE - created).total_seconds() / 86400)

    critical_rows = [
        row
        for row in rows
        if re.search(r"\b(critical|sev\s*1|severity\s*1|p1)\b", compact(row.get("Severity")), re.I)
    ]
    product_defect_rows = [row for row in rows if classify(row) == "Product Defects"]
    sentiment_counts = Counter(sentiment(row) for row in rows)

    by_month = Counter()
    for row in rows:
        created = parse_date(row.get("CreationDate"))
        if created:
            by_month[created.strftime("%Y-%m")] += 1

    category_rows = defaultdict(list)
    for row in closed_rows:
        category_rows[classify(row)].append(row)

    category_order = [
        "Setup / Configuration",
        "Upgrade / Maintenance / Patching",
        "Operations / IT Help",
        "Customization / Integration",
        "Break Fix / Functional Errors",
        "Documentation",
        "Product Defects",
        "Other",
    ]

    category_summary = []
    for category in category_order:
        examples = [compact(row.get("SRHeading")) for row in category_rows[category][:3]]
        category_summary.append(
            {
                "Category": category,
                "Closed SRs": len(category_rows[category]),
                "Summary": "; ".join(examples) if examples else "",
            }
        )

    result = {
        "total_requested": len(payload["requested"]),
        "fetched": len(rows),
        "errors": errors,
        "status_counts": status_counts,
        "severity_counts": severity_counts,
        "closed": len(closed_rows),
        "open": len(open_rows),
        "critical": len(critical_rows),
        "average_days_create_to_update": round(sum(update_diffs) / len(update_diffs), 1) if update_diffs else None,
        "average_open_age_days": round(sum(open_ages) / len(open_ages), 1) if open_ages else None,
        "product_defects": len(product_defect_rows),
        "sentiment_counts": sentiment_counts,
        "created_by_month": dict(sorted(by_month.items())),
        "category_summary": category_summary,
    }
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
