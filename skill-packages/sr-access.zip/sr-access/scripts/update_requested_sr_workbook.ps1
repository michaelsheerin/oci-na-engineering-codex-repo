param(
    [string]$WorkbookPath = (Join-Path (Get-Location) "sr_ocids_date.xlsx"),
    [string[]]$SrNumbers,
    [string]$SummarySheetName = "Requested SR Summary",
    [string]$EnvPath = (Join-Path (Get-Location) ".env")
)

$ErrorActionPreference = "Stop"

Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
Add-Type -AssemblyName System.Net.Http

$ReasonHeaderName = "Why was it in stuck state"
$InstanceReasonOverrides = @{
    # Add team-specific one-off OCID reason overrides here if needed.
    # Example: "example-instance-ocid" = "Unhealthy HV"
}

function Repair-Mojibake {
    param([string]$Text)

    if ([string]::IsNullOrEmpty($Text)) {
        return $Text
    }

    if ($Text -match "[ÃÂâ]") {
        $bytes = [System.Text.Encoding]::GetEncoding(28591).GetBytes($Text)
        return [System.Text.Encoding]::UTF8.GetString($bytes)
    }

    return $Text
}

function Load-DotEnv {
    param([string]$Path)

    if (-not (Test-Path -LiteralPath $Path)) {
        throw "Could not find .env at '$Path'."
    }

    $values = @{}
    foreach ($rawLine in Get-Content -LiteralPath $Path) {
        $line = $rawLine.Trim()
        if ([string]::IsNullOrWhiteSpace($line) -or $line.StartsWith("#")) {
            continue
        }

        $parts = $line -split "=", 2
        if ($parts.Count -eq 2) {
            $values[$parts[0].Trim()] = $parts[1]
        }
    }

    return $values
}

function Read-ZipEntryText {
    param(
        [System.IO.Compression.ZipArchive]$Archive,
        [string]$EntryName
    )

    $entry = $Archive.GetEntry($EntryName)
    if ($null -eq $entry) {
        return $null
    }

    $reader = New-Object System.IO.StreamReader($entry.Open())
    try {
        return $reader.ReadToEnd()
    }
    finally {
        $reader.Dispose()
    }
}

function Get-SharedStrings {
    param([System.IO.Compression.ZipArchive]$Archive)

    $text = Read-ZipEntryText -Archive $Archive -EntryName "xl/sharedStrings.xml"
    if ([string]::IsNullOrWhiteSpace($text)) {
        return @()
    }

    [xml]$xml = $text
    $ns = New-Object System.Xml.XmlNamespaceManager($xml.NameTable)
    $ns.AddNamespace("x", "http://schemas.openxmlformats.org/spreadsheetml/2006/main")

    $items = New-Object System.Collections.Generic.List[string]
    foreach ($si in $xml.SelectNodes("//x:si", $ns)) {
        $fragments = $si.SelectNodes(".//x:t", $ns) | ForEach-Object { $_.InnerText }
        $items.Add(($fragments -join ""))
    }

    return $items.ToArray()
}

function Get-WorksheetEntryName {
    param(
        [System.IO.Compression.ZipArchive]$Archive,
        [string]$PreferredSheetName
    )

    $workbookText = Read-ZipEntryText -Archive $Archive -EntryName "xl/workbook.xml"
    $relsText = Read-ZipEntryText -Archive $Archive -EntryName "xl/_rels/workbook.xml.rels"

    if ([string]::IsNullOrWhiteSpace($workbookText) -or [string]::IsNullOrWhiteSpace($relsText)) {
        return $null
    }

    [xml]$workbookXml = $workbookText
    [xml]$relsXml = $relsText

    $relsById = @{}
    foreach ($rel in $relsXml.Relationships.Relationship) {
        $target = [string]$rel.Target
        if ($target.StartsWith("/")) {
            $relsById[[string]$rel.Id] = $target.TrimStart("/")
        }
        elseif ($target.StartsWith("xl/")) {
            $relsById[[string]$rel.Id] = $target
        }
        else {
            $relsById[[string]$rel.Id] = "xl/$target"
        }
    }

    $ns = New-Object System.Xml.XmlNamespaceManager($workbookXml.NameTable)
    $ns.AddNamespace("x", "http://schemas.openxmlformats.org/spreadsheetml/2006/main")
    $ns.AddNamespace("r", "http://schemas.openxmlformats.org/officeDocument/2006/relationships")

    $selectedSheet = $null
    foreach ($sheet in $workbookXml.SelectNodes("//x:sheets/x:sheet", $ns)) {
        if ([string]$sheet.name -eq $PreferredSheetName) {
            $selectedSheet = $sheet
            break
        }
    }

    if ($null -eq $selectedSheet) {
        $selectedSheet = $workbookXml.SelectSingleNode("//x:sheets/x:sheet[1]", $ns)
    }

    if ($null -eq $selectedSheet) {
        return $null
    }

    $relationshipNamespace = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
    $relationshipId = $selectedSheet.GetAttribute("id", $relationshipNamespace)

    return $relsById[$relationshipId]
}

function Get-CellValue {
    param(
        [System.Xml.XmlNode]$Cell,
        [System.Xml.XmlNamespaceManager]$NamespaceManager,
        [string[]]$SharedStrings
    )

    $cellType = $Cell.GetAttribute("t")

    if ($cellType -eq "inlineStr") {
        $parts = $Cell.SelectNodes(".//x:t", $NamespaceManager) | ForEach-Object { $_.InnerText }
        return $parts -join ""
    }

    $valueNode = $Cell.SelectSingleNode("./x:v", $NamespaceManager)
    if ($null -eq $valueNode) {
        return ""
    }

    $value = $valueNode.InnerText
    if ($cellType -eq "s") {
        $index = [int]$value
        if ($index -ge 0 -and $index -lt $SharedStrings.Count) {
            return $SharedStrings[$index]
        }

        return ""
    }

    return $value
}

function Get-HashtableValueOrEmpty {
    param(
        [hashtable]$Hashtable,
        [string]$Key
    )

    if ([string]::IsNullOrWhiteSpace($Key)) {
        return ""
    }

    if ($Hashtable.ContainsKey($Key)) {
        return [string]$Hashtable[$Key]
    }

    return ""
}

function Get-ExistingSrOcidRows {
    param([string]$Path)

    if (-not (Test-Path -LiteralPath $Path)) {
        return @()
    }

    $archive = [System.IO.Compression.ZipFile]::OpenRead($Path)
    try {
        $worksheetEntryName = Get-WorksheetEntryName -Archive $archive -PreferredSheetName "SR OCIDs"
        if ([string]::IsNullOrWhiteSpace($worksheetEntryName)) {
            return @()
        }

        $sheetText = Read-ZipEntryText -Archive $archive -EntryName $worksheetEntryName
        if ([string]::IsNullOrWhiteSpace($sheetText)) {
            return @()
        }

        $sharedStrings = Get-SharedStrings -Archive $archive

        [xml]$sheetXml = $sheetText
        $ns = New-Object System.Xml.XmlNamespaceManager($sheetXml.NameTable)
        $ns.AddNamespace("x", "http://schemas.openxmlformats.org/spreadsheetml/2006/main")

        $rows = New-Object System.Collections.Generic.List[object]
        $seen = @{}
        $headerMap = @{}
        $srColumn = "A"
        $createdColumn = "B"
        $ocidColumn = "C"
        $reasonColumn = $null
        $headerProcessed = $false

        foreach ($row in $sheetXml.SelectNodes("//x:sheetData/x:row", $ns)) {
            $cellsByColumn = @{}
            foreach ($cell in $row.SelectNodes("./x:c", $ns)) {
                $reference = [string]$cell.r
                $column = $reference -replace "\d", ""
                $cellsByColumn[$column] = Get-CellValue -Cell $cell -NamespaceManager $ns -SharedStrings $sharedStrings
            }

            if (-not $headerProcessed) {
                foreach ($column in $cellsByColumn.Keys) {
                    $headerValue = [string]$cellsByColumn[$column]
                    if (-not [string]::IsNullOrWhiteSpace($headerValue)) {
                        $headerMap[$headerValue] = $column
                    }
                }

                if ($headerMap.ContainsKey("SR")) {
                    $srColumn = [string]$headerMap["SR"]
                }
                if ($headerMap.ContainsKey("SRCreatedDate")) {
                    $createdColumn = [string]$headerMap["SRCreatedDate"]
                }
                if ($headerMap.ContainsKey("InstanceOCID")) {
                    $ocidColumn = [string]$headerMap["InstanceOCID"]
                }
                if ($headerMap.ContainsKey($ReasonHeaderName)) {
                    $reasonColumn = [string]$headerMap[$ReasonHeaderName]
                }

                $headerProcessed = $true
                continue
            }

            $sr = Get-HashtableValueOrEmpty -Hashtable $cellsByColumn -Key $srColumn
            $created = Get-HashtableValueOrEmpty -Hashtable $cellsByColumn -Key $createdColumn
            $ocid = Get-HashtableValueOrEmpty -Hashtable $cellsByColumn -Key $ocidColumn
            $reason = Get-HashtableValueOrEmpty -Hashtable $cellsByColumn -Key $reasonColumn

            if ([string]::IsNullOrWhiteSpace($sr)) {
                continue
            }

            $key = "$sr|$ocid"
            if ($seen.ContainsKey($key)) {
                if ([string]::IsNullOrWhiteSpace($seen[$key].SRCreatedDate) -and -not [string]::IsNullOrWhiteSpace($created)) {
                    $seen[$key].SRCreatedDate = $created
                }
                if ([string]::IsNullOrWhiteSpace($seen[$key].StuckReason) -and -not [string]::IsNullOrWhiteSpace($reason)) {
                    $seen[$key].StuckReason = $reason
                }
                continue
            }

            $rowObject = [PSCustomObject]@{
                SR = $sr
                SRCreatedDate = $created
                InstanceOCID = $ocid
                StuckReason = $reason
            }

            $rows.Add($rowObject)
            $seen[$key] = $rowObject
        }

        return $rows.ToArray()
    }
    finally {
        $archive.Dispose()
    }
}

function Get-ExistingSummaryRows {
    param(
        [string]$Path,
        [string]$SheetName
    )

    if (-not (Test-Path -LiteralPath $Path)) {
        return @()
    }

    $archive = [System.IO.Compression.ZipFile]::OpenRead($Path)
    try {
        $worksheetEntryName = Get-WorksheetEntryName -Archive $archive -PreferredSheetName $SheetName
        if ([string]::IsNullOrWhiteSpace($worksheetEntryName)) {
            return @()
        }

        $sheetText = Read-ZipEntryText -Archive $archive -EntryName $worksheetEntryName
        if ([string]::IsNullOrWhiteSpace($sheetText)) {
            return @()
        }

        $sharedStrings = Get-SharedStrings -Archive $archive

        [xml]$sheetXml = $sheetText
        $ns = New-Object System.Xml.XmlNamespaceManager($sheetXml.NameTable)
        $ns.AddNamespace("x", "http://schemas.openxmlformats.org/spreadsheetml/2006/main")

        $rows = New-Object System.Collections.Generic.List[object]
        $seen = @{}
        $headerMap = @{}
        $headerProcessed = $false
        $srColumn = "A"
        $headingColumn = "B"
        $monthColumn = "C"
        $dateRaisedColumn = "D"
        $severityColumn = "E"
        $dataCenterColumn = "F"
        $statusColumn = "G"
        $createdByColumn = "H"
        $srOwnerColumn = "I"
        $ocidsColumn = "J"
        $reasonColumn = $null

        foreach ($row in $sheetXml.SelectNodes("//x:sheetData/x:row", $ns)) {
            $cellsByColumn = @{}
            foreach ($cell in $row.SelectNodes("./x:c", $ns)) {
                $reference = [string]$cell.r
                $column = $reference -replace "\d", ""
                $cellsByColumn[$column] = Get-CellValue -Cell $cell -NamespaceManager $ns -SharedStrings $sharedStrings
            }

            if (-not $headerProcessed) {
                foreach ($column in $cellsByColumn.Keys) {
                    $headerValue = [string]$cellsByColumn[$column]
                    if (-not [string]::IsNullOrWhiteSpace($headerValue)) {
                        $headerMap[$headerValue] = $column
                    }
                }

                if ($headerMap.ContainsKey("SR Number")) {
                    $srColumn = [string]$headerMap["SR Number"]
                }
                elseif ($headerMap.ContainsKey("SR")) {
                    $srColumn = [string]$headerMap["SR"]
                }
                if ($headerMap.ContainsKey("Task / Notes")) {
                    $headingColumn = [string]$headerMap["Task / Notes"]
                }
                elseif ($headerMap.ContainsKey("SR Heading")) {
                    $headingColumn = [string]$headerMap["SR Heading"]
                }
                if ($headerMap.ContainsKey("Month")) {
                    $monthColumn = [string]$headerMap["Month"]
                }
                if ($headerMap.ContainsKey("Date Raised")) {
                    $dateRaisedColumn = [string]$headerMap["Date Raised"]
                }
                if ($headerMap.ContainsKey("Severity")) {
                    $severityColumn = [string]$headerMap["Severity"]
                }
                if ($headerMap.ContainsKey("Data Center")) {
                    $dataCenterColumn = [string]$headerMap["Data Center"]
                }
                if ($headerMap.ContainsKey("Status")) {
                    $statusColumn = [string]$headerMap["Status"]
                }
                if ($headerMap.ContainsKey("Raised By")) {
                    $createdByColumn = [string]$headerMap["Raised By"]
                }
                elseif ($headerMap.ContainsKey("Created By")) {
                    $createdByColumn = [string]$headerMap["Created By"]
                }
                if ($headerMap.ContainsKey("SR Owner")) {
                    $srOwnerColumn = [string]$headerMap["SR Owner"]
                }
                if ($headerMap.ContainsKey("OCID(s)")) {
                    $ocidsColumn = [string]$headerMap["OCID(s)"]
                }
                if ($headerMap.ContainsKey($ReasonHeaderName)) {
                    $reasonColumn = [string]$headerMap[$ReasonHeaderName]
                }

                $headerProcessed = $true
                continue
            }

            $sr = Get-HashtableValueOrEmpty -Hashtable $cellsByColumn -Key $srColumn
            if ([string]::IsNullOrWhiteSpace($sr)) {
                continue
            }

            if ($seen.ContainsKey($sr)) {
                continue
            }

            $rowObject = [PSCustomObject]@{
                SR = $sr
                SRHeading = Get-HashtableValueOrEmpty -Hashtable $cellsByColumn -Key $headingColumn
                Month = Get-HashtableValueOrEmpty -Hashtable $cellsByColumn -Key $monthColumn
                DateRaised = Get-HashtableValueOrEmpty -Hashtable $cellsByColumn -Key $dateRaisedColumn
                Severity = Get-HashtableValueOrEmpty -Hashtable $cellsByColumn -Key $severityColumn
                DataCenter = Get-HashtableValueOrEmpty -Hashtable $cellsByColumn -Key $dataCenterColumn
                Status = Get-HashtableValueOrEmpty -Hashtable $cellsByColumn -Key $statusColumn
                CreatedBy = Get-HashtableValueOrEmpty -Hashtable $cellsByColumn -Key $createdByColumn
                SROwner = Get-HashtableValueOrEmpty -Hashtable $cellsByColumn -Key $srOwnerColumn
                OCIDsText = Get-HashtableValueOrEmpty -Hashtable $cellsByColumn -Key $ocidsColumn
                StuckReason = Get-HashtableValueOrEmpty -Hashtable $cellsByColumn -Key $reasonColumn
            }

            $rows.Add($rowObject)
            $seen[$sr] = $true
        }

        return $rows.ToArray()
    }
    finally {
        $archive.Dispose()
    }
}

function Convert-ColumnIndexToName {
    param([int]$Index)

    $name = ""
    $current = $Index

    while ($current -gt 0) {
        $current--
        $name = [char](65 + ($current % 26)) + $name
        $current = [math]::Floor($current / 26)
    }

    return $name
}

function New-InlineCellXml {
    param(
        [string]$Reference,
        [string]$Value
    )

    $escapedValue = [System.Security.SecurityElement]::Escape([string]$Value)
    if ($null -eq $escapedValue) {
        $escapedValue = ""
    }

    return "<c r=`"$Reference`" t=`"inlineStr`"><is><t xml:space=`"preserve`">$escapedValue</t></is></c>"
}

function New-RowXml {
    param(
        [int]$RowNumber,
        [string[]]$Values
    )

    $cells = for ($i = 0; $i -lt $Values.Count; $i++) {
        $columnName = Convert-ColumnIndexToName -Index ($i + 1)
        New-InlineCellXml -Reference ($columnName + $RowNumber) -Value $Values[$i]
    }

    return "<row r=`"$RowNumber`">$($cells -join '')</row>"
}

function New-WorksheetXml {
    param([object[]]$Rows)

    $maxColumns = 1
    foreach ($row in $Rows) {
        if ($row.Count -gt $maxColumns) {
            $maxColumns = $row.Count
        }
    }

    $lastRow = [math]::Max(1, $Rows.Count)
    $lastColumn = Convert-ColumnIndexToName -Index $maxColumns

    $rowXml = New-Object System.Collections.Generic.List[string]
    $excelRowNumber = 1
    foreach ($row in $Rows) {
        $stringValues = @($row | ForEach-Object { [string]$_ })
        $rowXml.Add((New-RowXml -RowNumber $excelRowNumber -Values $stringValues))
        $excelRowNumber++
    }

    return @"
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <dimension ref="A1:$lastColumn$lastRow"/>
  <sheetData>
    $($rowXml -join "`n    ")
  </sheetData>
</worksheet>
"@
}

function Add-ZipEntry {
    param(
        [System.IO.Compression.ZipArchive]$Archive,
        [string]$EntryName,
        [string]$Content
    )

    $entry = $Archive.CreateEntry($EntryName)
    $stream = $entry.Open()
    $writer = New-Object System.IO.StreamWriter($stream, [System.Text.UTF8Encoding]::new($false))
    try {
        $writer.Write($Content)
    }
    finally {
        $writer.Dispose()
    }
}

function Write-Workbook {
    param(
        [string]$OutputPath,
        [object[]]$Sheets
    )

    $overrides = New-Object System.Collections.Generic.List[string]
    $sheetEntries = New-Object System.Collections.Generic.List[string]
    $sheetRelationships = New-Object System.Collections.Generic.List[string]

    for ($i = 0; $i -lt $Sheets.Count; $i++) {
        $sheetNumber = $i + 1
        $sheetName = [System.Security.SecurityElement]::Escape([string]$Sheets[$i].Name)
        $sheetEntries.Add("    <sheet name=`"$sheetName`" sheetId=`"$sheetNumber`" r:id=`"rId$sheetNumber`"/>")
        $sheetRelationships.Add("  <Relationship Id=`"rId$sheetNumber`" Type=`"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet`" Target=`"worksheets/sheet$sheetNumber.xml`"/>")
        $overrides.Add("  <Override PartName=`"/xl/worksheets/sheet$sheetNumber.xml`" ContentType=`"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml`"/>")
    }

    $contentTypesXml = @"
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
$($overrides -join "`n")
</Types>
"@

    $rootRelsXml = @"
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>
"@

    $workbookXml = @"
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheets>
$($sheetEntries -join "`n")
  </sheets>
</workbook>
"@

    $workbookRelsXml = @"
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
$($sheetRelationships -join "`n")
</Relationships>
"@

    $outputDirectory = Split-Path -Parent $OutputPath
    if (-not [string]::IsNullOrWhiteSpace($outputDirectory) -and -not (Test-Path -LiteralPath $outputDirectory)) {
        New-Item -ItemType Directory -Path $outputDirectory | Out-Null
    }

    $fileStream = [System.IO.File]::Open($OutputPath, [System.IO.FileMode]::Create)
    try {
        $archive = New-Object System.IO.Compression.ZipArchive($fileStream, [System.IO.Compression.ZipArchiveMode]::Create, $false)
        try {
            Add-ZipEntry -Archive $archive -EntryName "[Content_Types].xml" -Content $contentTypesXml
            Add-ZipEntry -Archive $archive -EntryName "_rels/.rels" -Content $rootRelsXml
            Add-ZipEntry -Archive $archive -EntryName "xl/workbook.xml" -Content $workbookXml
            Add-ZipEntry -Archive $archive -EntryName "xl/_rels/workbook.xml.rels" -Content $workbookRelsXml

            for ($i = 0; $i -lt $Sheets.Count; $i++) {
                $sheetNumber = $i + 1
                Add-ZipEntry -Archive $archive -EntryName "xl/worksheets/sheet$sheetNumber.xml" -Content $Sheets[$i].Xml
            }
        }
        finally {
            $archive.Dispose()
        }
    }
    finally {
        $fileStream.Dispose()
    }
}

function Get-JsonFromApi {
    param(
        [System.Net.Http.HttpClient]$HttpClient,
        [string]$Url
    )

    $request = [System.Net.Http.HttpRequestMessage]::new([System.Net.Http.HttpMethod]::Get, $Url)
    $null = $request.Headers.TryAddWithoutValidation("Accept", "application/json")

    $response = $HttpClient.SendAsync($request).GetAwaiter().GetResult()
    if (-not $response.IsSuccessStatusCode) {
        $statusCode = [int]$response.StatusCode
        $reasonPhrase = [string]$response.ReasonPhrase
        $request.Dispose()
        throw "GET $Url failed with HTTP $statusCode $reasonPhrase."
    }

    try {
        $json = $response.Content.ReadAsStringAsync().GetAwaiter().GetResult()
        return $json | ConvertFrom-Json
    }
    finally {
        $request.Dispose()
    }
}

function Get-TextFromApi {
    param(
        [System.Net.Http.HttpClient]$HttpClient,
        [string]$Url
    )

    $request = [System.Net.Http.HttpRequestMessage]::new([System.Net.Http.HttpMethod]::Get, $Url)
    $null = $request.Headers.TryAddWithoutValidation("Accept", "*/*")

    $response = $HttpClient.SendAsync($request).GetAwaiter().GetResult()
    try {
        if (-not $response.IsSuccessStatusCode) {
            return ""
        }

        return $response.Content.ReadAsStringAsync().GetAwaiter().GetResult()
    }
    finally {
        $request.Dispose()
    }
}

function Add-UniqueString {
    param(
        [System.Collections.Generic.List[string]]$List,
        [string]$Value
    )

    if ([string]::IsNullOrWhiteSpace($Value)) {
        return
    }

    if (-not ($List -contains $Value)) {
        $List.Add($Value) | Out-Null
    }
}

function Remove-PrefixOcids {
    param([string[]]$Values)

    $orderedUnique = New-Object System.Collections.Generic.List[string]
    foreach ($value in $Values) {
        if ([string]::IsNullOrWhiteSpace($value)) {
            continue
        }

        if (-not ($orderedUnique -contains $value)) {
            $orderedUnique.Add($value) | Out-Null
        }
    }

    $prefixMatches = @{}
    foreach ($value in $orderedUnique) {
        foreach ($other in $orderedUnique) {
            if (
                $value -ne $other -and
                $other.Length -gt $value.Length -and
                $other.StartsWith($value, [System.StringComparison]::OrdinalIgnoreCase)
            ) {
                $prefixMatches[$value] = $true
                break
            }
        }
    }

    return @(
        $orderedUnique | Where-Object { -not $prefixMatches.ContainsKey($_) }
    )
}

function Get-InstanceOcidsFromText {
    param([string]$Text)

    if ([string]::IsNullOrWhiteSpace($Text)) {
        return @()
    }

    return [regex]::Matches($Text, "ocid1\.instance\.[A-Za-z0-9._-]+", [System.Text.RegularExpressions.RegexOptions]::IgnoreCase) |
        ForEach-Object { $_.Value } |
        Sort-Object -Unique
}

function Get-DataCentersFromOcids {
    param([string[]]$Ocids)

    $dataCenters = New-Object System.Collections.Generic.List[string]
    foreach ($ocid in (Remove-PrefixOcids -Values $Ocids)) {
        if ([string]::IsNullOrWhiteSpace($ocid)) {
            continue
        }

        $parts = $ocid -split "\."
        if ($parts.Count -le 3) {
            continue
        }

        $dataCenter = [string]$parts[3]
        if (-not [string]::IsNullOrWhiteSpace($dataCenter) -and -not ($dataCenters -contains $dataCenter)) {
            $dataCenters.Add($dataCenter) | Out-Null
        }
    }

    if ($dataCenters.Count -eq 0) {
        return ""
    }

    return ($dataCenters.ToArray() -join "; ")
}

function Get-StuckReasonFromText {
    param([string]$Text)

    if ([string]::IsNullOrWhiteSpace($Text)) {
        return ""
    }

    $reasons = New-Object System.Collections.Generic.List[string]
    $instanceOcids = Get-InstanceOcidsFromText -Text $Text

    foreach ($instanceOcid in $instanceOcids) {
        $reason = ""
        if ($InstanceReasonOverrides.ContainsKey($instanceOcid)) {
            $reason = $InstanceReasonOverrides[$instanceOcid]
        }
        elseif ($instanceOcid -match "ocid1\.instance\.oc1\.eu-frankfurt-1\.") {
            $reason = "Out of capacity error"
        }
        elseif ($instanceOcid -match "ocid1\.instance\.oc1\.iad\.") {
            $reason = "Bad HV"
        }

        if (-not [string]::IsNullOrWhiteSpace($reason) -and -not ($reasons -contains $reason)) {
            $reasons.Add($reason) | Out-Null
        }
    }

    if ($reasons.Count -eq 0) {
        return ""
    }

    return ($reasons.ToArray() -join "; ")
}

function Join-UniqueReasons {
    param([string[]]$Values)

    $reasons = New-Object System.Collections.Generic.List[string]
    foreach ($value in $Values) {
        if ([string]::IsNullOrWhiteSpace($value)) {
            continue
        }

        foreach ($reason in ($value -split "\s*;\s*" | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })) {
            if (-not ($reasons -contains $reason)) {
                $reasons.Add($reason) | Out-Null
            }
        }
    }

    if ($reasons.Count -eq 0) {
        return ""
    }

    return ($reasons.ToArray() -join "; ")
}

function Get-ResolvedStuckReason {
    param(
        [string]$Text,
        [string]$ExistingReasons = ""
    )

    return Join-UniqueReasons -Values @(
        $ExistingReasons
        (Get-StuckReasonFromText -Text $Text)
    )
}

function Get-DateParts {
    param([string]$IsoDate)

    if ([string]::IsNullOrWhiteSpace($IsoDate)) {
        return [PSCustomObject]@{
            Month = ""
            Date = ""
        }
    }

    $parsed = [System.DateTimeOffset]::Parse($IsoDate)
    return [PSCustomObject]@{
        Month = $parsed.ToString("yyyy-MM")
        Date = $parsed.ToString("yyyy-MM-dd")
    }
}

if ($null -eq $SrNumbers -or $SrNumbers.Count -eq 0) {
    throw "Please provide one or more SR numbers via -SrNumbers."
}

$orderedSrNumbers = New-Object System.Collections.Generic.List[string]
foreach ($srNumber in $SrNumbers) {
    if (-not [string]::IsNullOrWhiteSpace($srNumber) -and -not ($orderedSrNumbers -contains $srNumber)) {
        $orderedSrNumbers.Add($srNumber.Trim()) | Out-Null
    }
}

if (-not [System.IO.Path]::IsPathRooted($WorkbookPath)) {
    $WorkbookPath = Join-Path (Get-Location) $WorkbookPath
}
$WorkbookPath = [System.IO.Path]::GetFullPath($WorkbookPath)

if (-not [System.IO.Path]::IsPathRooted($EnvPath)) {
    $EnvPath = Join-Path (Get-Location) $EnvPath
}
$EnvPath = [System.IO.Path]::GetFullPath($EnvPath)

$envValues = Load-DotEnv -Path $EnvPath
if (-not $envValues.ContainsKey("SR_BASE_URL")) {
    throw "SR_BASE_URL is missing in '$EnvPath'."
}

$authorizationHeader = $null
if ($envValues.ContainsKey("SR_AUTH_HEADER")) {
    $authorizationHeader = $envValues["SR_AUTH_HEADER"]
}
elseif ($envValues.ContainsKey("SR_BEARER_TOKEN")) {
    $authorizationHeader = "Bearer $($envValues["SR_BEARER_TOKEN"])"
}

if ([string]::IsNullOrWhiteSpace($authorizationHeader)) {
    throw "Could not find SR_AUTH_HEADER or SR_BEARER_TOKEN in '$EnvPath'."
}

$resourcePath = "/crmRestApi/resources/11.13.18.05/serviceRequests"
if ($envValues.ContainsKey("SR_RESOURCE_PATH") -and $envValues["SR_RESOURCE_PATH"] -match "/crmRestApi/.*/serviceRequests$") {
    $resourcePath = $envValues["SR_RESOURCE_PATH"]
}

$serviceRequestBaseUrl = $envValues["SR_BASE_URL"].TrimEnd("/") + $resourcePath

$existingRows = Get-ExistingSrOcidRows -Path $WorkbookPath
$existingSummaryRows = Get-ExistingSummaryRows -Path $WorkbookPath -SheetName $SummarySheetName
$existingRowsBySr = @{}
foreach ($row in $existingRows) {
    if (-not $existingRowsBySr.ContainsKey($row.SR)) {
        $existingRowsBySr[$row.SR] = New-Object System.Collections.Generic.List[object]
    }

    $existingRowsBySr[$row.SR].Add($row) | Out-Null
}
$existingSummaryRowsBySr = @{}
foreach ($row in $existingSummaryRows) {
    if (-not $existingSummaryRowsBySr.ContainsKey($row.SR)) {
        $existingSummaryRowsBySr[$row.SR] = $row
    }
}

$httpClient = [System.Net.Http.HttpClient]::new()
$httpClient.Timeout = [TimeSpan]::FromSeconds(60)
$null = $httpClient.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", $authorizationHeader)

$summaryBySr = @{}
try {
    foreach ($srNumber in $orderedSrNumbers) {
        $sr = Get-JsonFromApi -HttpClient $httpClient -Url "$serviceRequestBaseUrl/$srNumber"
        $dateParts = Get-DateParts -IsoDate $sr.CreationDate

        $fetchedOcids = New-Object System.Collections.Generic.List[string]
        foreach ($field in @(
                [string]$sr.Title,
                [string]$sr.ProblemDescription,
                [string]$sr.SRDescription_c,
                [string]$sr.ResolveDescription,
                [string]$sr.TransferNote
            )) {
            foreach ($ocid in (Get-InstanceOcidsFromText -Text $field)) {
                Add-UniqueString -List $fetchedOcids -Value $ocid
            }
        }

        $messages = Get-JsonFromApi -HttpClient $httpClient -Url "$serviceRequestBaseUrl/$srNumber/child/messages?limit=500"
        foreach ($message in @($messages.items)) {
            $createdBy = [string]$message.CreatedBy
            $createdByEmail = [string]$message.CreatedByEmailAddress
            $isCustomerAuthored = (
                (-not [string]::IsNullOrWhiteSpace($createdBy) -and $createdBy -notlike "*@oracle.com") -or
                (-not [string]::IsNullOrWhiteSpace($createdByEmail) -and $createdByEmail -notlike "*@oracle.com")
            )

            if (-not $isCustomerAuthored) {
                continue
            }

            $messageContent = Get-TextFromApi -HttpClient $httpClient -Url "$serviceRequestBaseUrl/$srNumber/child/messages/$($message.MessageId)/enclosure/MessageContent"
            foreach ($ocid in (Get-InstanceOcidsFromText -Text $messageContent)) {
                Add-UniqueString -List $fetchedOcids -Value $ocid
            }
        }

        $finalOcids = New-Object System.Collections.Generic.List[string]
        if ($existingRowsBySr.ContainsKey($srNumber)) {
            $existingRowsForSr = $existingRowsBySr[$srNumber].ToArray()
        }
        else {
            $existingRowsForSr = @()
        }

        foreach ($existingRow in $existingRowsForSr) {
            Add-UniqueString -List $finalOcids -Value ([string]$existingRow.InstanceOCID)
        }
        foreach ($fetchedOcid in $fetchedOcids) {
            Add-UniqueString -List $finalOcids -Value $fetchedOcid
        }
        $resolvedOcids = Remove-PrefixOcids -Values $finalOcids.ToArray()

        $rawStatus = Repair-Mojibake -Text ([string]$sr.StatusCdMeaning)
        $isClosed = $false
        if ($sr.ClosedSR_c -or $sr.ClosedDate) {
            $isClosed = $true
        }
        elseif ($rawStatus -match "^(Resolved|Closed)$") {
            $isClosed = $true
        }

        $summaryBySr[$srNumber] = [PSCustomObject]@{
            SR = $srNumber
            SRHeading = Repair-Mojibake -Text ([string]$sr.Title)
            Month = $dateParts.Month
            DateRaised = $dateParts.Date
            Severity = Repair-Mojibake -Text ([string]$sr.SeverityCdMeaning)
            DataCenter = Get-DataCentersFromOcids -Ocids $resolvedOcids
            Status = if ($isClosed) { "Closed" } else { "Open" }
            CreatedBy = Repair-Mojibake -Text ([string]$sr.CreatedBy)
            SROwner = Repair-Mojibake -Text ([string]$sr.AssigneePersonName)
            OCIDs = $resolvedOcids
        }
    }
}
finally {
    $httpClient.Dispose()
}

$existingRows = @(
    $existingRows | Where-Object {
        if (-not $summaryBySr.ContainsKey($_.SR)) {
            return $true
        }

        $resolvedOcids = @($summaryBySr[$_.SR].OCIDs | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
        if (-not [string]::IsNullOrWhiteSpace($_.InstanceOCID) -and -not ($resolvedOcids -contains $_.InstanceOCID)) {
            return $false
        }
        if ($resolvedOcids.Count -gt 0 -and [string]::IsNullOrWhiteSpace($_.InstanceOCID)) {
            return $false
        }

        return $true
    }
)

foreach ($existingRow in $existingRows) {
    if ($summaryBySr.ContainsKey($existingRow.SR)) {
        $summary = $summaryBySr[$existingRow.SR]
        if (-not [string]::IsNullOrWhiteSpace($summary.DateRaised)) {
            $existingRow.SRCreatedDate = $summary.DateRaised
        }
    }

    $existingRow.StuckReason = Get-ResolvedStuckReason -Text ([string]$existingRow.InstanceOCID) -ExistingReasons ([string]$existingRow.StuckReason)
}

$existingKeySet = @{}
foreach ($row in $existingRows) {
    $existingKeySet["$($row.SR)|$($row.InstanceOCID)"] = $true
}

foreach ($srNumber in $orderedSrNumbers) {
    $summary = $summaryBySr[$srNumber]
    $ocids = @($summary.OCIDs | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })

    if ($ocids.Count -gt 0) {
        foreach ($ocid in $ocids) {
            $key = "$srNumber|$ocid"
            if ($existingKeySet.ContainsKey($key)) {
                continue
            }

            $existingRows += [PSCustomObject]@{
                SR = $srNumber
                SRCreatedDate = $summary.DateRaised
                InstanceOCID = $ocid
                StuckReason = Get-ResolvedStuckReason -Text $ocid
            }
            $existingKeySet[$key] = $true
        }
    }
    else {
        $blankKey = "$srNumber|"
        if (-not $existingKeySet.ContainsKey($blankKey)) {
            $existingRows += [PSCustomObject]@{
                SR = $srNumber
                SRCreatedDate = $summary.DateRaised
                InstanceOCID = ""
                StuckReason = ""
            }
            $existingKeySet[$blankKey] = $true
        }
    }
}

$existingRows = @($existingRows | Sort-Object SRCreatedDate, SR, InstanceOCID)

$ocidSheetRows = @(
    ,@("SR", "SRCreatedDate", "InstanceOCID", $ReasonHeaderName)
)
foreach ($row in $existingRows) {
    $ocidSheetRows += ,@(
        [string]$row.SR,
        [string]$row.SRCreatedDate,
        [string]$row.InstanceOCID,
        [string]$row.StuckReason
    )
}

$mergedSummaryRowsBySr = @{}
foreach ($existingSummaryRow in $existingSummaryRows) {
    if (-not $mergedSummaryRowsBySr.ContainsKey($existingSummaryRow.SR)) {
        $mergedSummaryRowsBySr[$existingSummaryRow.SR] = $existingSummaryRow
    }
}

foreach ($srNumber in $orderedSrNumbers) {
    $summary = $summaryBySr[$srNumber]
    $existingSummaryRow = $null
    if ($mergedSummaryRowsBySr.ContainsKey($srNumber)) {
        $existingSummaryRow = $mergedSummaryRowsBySr[$srNumber]
    }

    $existingReasons = ""
    if ($null -ne $existingSummaryRow) {
        $existingReasons = [string]$existingSummaryRow.StuckReason
    }

    $mergedSummaryRowsBySr[$srNumber] = [PSCustomObject]@{
        SR = [string]$summary.SR
        SRHeading = [string]$summary.SRHeading
        Month = [string]$summary.Month
        DateRaised = [string]$summary.DateRaised
        Severity = [string]$summary.Severity
        DataCenter = if ([string]::IsNullOrWhiteSpace([string]$summary.DataCenter) -and $null -ne $existingSummaryRow) { [string]$existingSummaryRow.DataCenter } else { [string]$summary.DataCenter }
        Status = [string]$summary.Status
        CreatedBy = [string]$summary.CreatedBy
        SROwner = [string]$summary.SROwner
        OCIDsText = (@($summary.OCIDs) -join "; ")
        StuckReason = Get-ResolvedStuckReason -Text ((@($summary.OCIDs) -join "; ")) -ExistingReasons $existingReasons
    }
}

$mergedSummaryRows = @($mergedSummaryRowsBySr.Values | Sort-Object DateRaised, SR)

$summarySheetRows = @(
    ,@("SR Number", "Task / Notes", "Month", "Date Raised", "Severity", "Data Center", "Status", "Raised By", "SR Owner", "OCID(s)", $ReasonHeaderName)
)
foreach ($summaryRow in $mergedSummaryRows) {
    $summarySheetRows += ,@(
        [string]$summaryRow.SR,
        [string]$summaryRow.SRHeading,
        [string]$summaryRow.Month,
        [string]$summaryRow.DateRaised,
        [string]$summaryRow.Severity,
        [string]$summaryRow.DataCenter,
        [string]$summaryRow.Status,
        [string]$summaryRow.CreatedBy,
        [string]$summaryRow.SROwner,
        [string]$summaryRow.OCIDsText,
        [string]$summaryRow.StuckReason
    )
}

if (Test-Path -LiteralPath $WorkbookPath) {
    $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $directory = Split-Path -Parent $WorkbookPath
    $filename = [System.IO.Path]::GetFileNameWithoutExtension($WorkbookPath)
    $extension = [System.IO.Path]::GetExtension($WorkbookPath)
    $backupPath = Join-Path $directory "$filename.backup_$timestamp$extension"
    Copy-Item -LiteralPath $WorkbookPath -Destination $backupPath -Force
}
else {
    $backupPath = $null
}

$sheets = @(
    [PSCustomObject]@{
        Name = "SR OCIDs"
        Xml = New-WorksheetXml -Rows $ocidSheetRows
    },
    [PSCustomObject]@{
        Name = $SummarySheetName
        Xml = New-WorksheetXml -Rows $summarySheetRows
    }
)

Write-Workbook -OutputPath $WorkbookPath -Sheets $sheets

[PSCustomObject]@{
    WorkbookPath = (Resolve-Path -LiteralPath $WorkbookPath).Path
    BackupPath = if ($backupPath) { (Resolve-Path -LiteralPath $backupPath).Path } else { "" }
    RequestedSrCount = $orderedSrNumbers.Count
    SummarySheetName = $SummarySheetName
} | ConvertTo-Json -Depth 4
