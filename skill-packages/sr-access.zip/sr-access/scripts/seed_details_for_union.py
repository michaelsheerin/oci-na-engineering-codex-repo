import argparse
import json
from pathlib import Path


def load_list(path):
    seen = set()
    values = []
    for raw_line in Path(path).read_text(encoding="utf-8").splitlines():
        value = raw_line.strip()
        if value and value not in seen:
            values.append(value)
            seen.add(value)
    return values


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--union-list", required=True)
    parser.add_argument("--existing-details", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    requested = load_list(args.union_list)
    existing = json.loads(Path(args.existing_details).read_text(encoding="utf-8"))
    requested_set = set(requested)
    rows = [row for row in existing.get("rows", []) if row.get("SR") in requested_set]
    errors = [row for row in existing.get("errors", []) if row.get("SR") in requested_set]
    payload = {"requested": requested, "rows": rows, "errors": errors}
    Path(args.output).write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print({"requested": len(requested), "seededRows": len(rows), "seededErrors": len(errors)})


if __name__ == "__main__":
    main()
