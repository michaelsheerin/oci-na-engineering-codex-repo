param(
    [string]$WorkbookPath = (Join-Path (Get-Location) "sr_ocids_date.xlsx"),
    [Parameter(Mandatory = $true)]
    [string]$SrNumber,
    [Parameter(Mandatory = $true)]
    [string]$InstanceOCID,
    [string]$SummarySheetName = "Requested SR Summary",
    [string]$StuckReason = "",
    [string]$OutputPath = ""
)

$ErrorActionPreference = "Stop"

Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

$SpreadsheetNamespace = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
$RelationshipNamespace = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
$XmlNamespace = "http://www.w3.org/XML/1998/namespace"
$ReasonHeaderName = "Why was it in stuck state"
$InstanceReasonOverrides = @{
    # Add team-specific one-off OCID reason overrides here if needed.
    # Example: "example-instance-ocid" = "Unhealthy HV"
}

function Read-ZipEntryText {
    param(
        [System.IO.Compression.ZipArchive]$Archive,
        [string]$EntryName
    )

    $entry = $Archive.GetEntry($EntryName)
    if ($null -eq $entry) {
        return $null
    }

    $reader = New-Object System.IO.StreamReader($entry.Open())
    try {
        return $reader.ReadToEnd()
    }
    finally {
        $reader.Dispose()
    }
}

function Get-SharedStrings {
    param([System.IO.Compression.ZipArchive]$Archive)

    $text = Read-ZipEntryText -Archive $Archive -EntryName "xl/sharedStrings.xml"
    if ([string]::IsNullOrWhiteSpace($text)) {
        return @()
    }

    [xml]$xml = $text

    $items = New-Object System.Collections.Generic.List[string]
    $xmlNode = [System.Xml.XmlNode]$xml
    foreach ($si in $xmlNode.SelectNodes("//*[local-name()='si']")) {
        $siNode = [System.Xml.XmlNode]$si
        $parts = $siNode.SelectNodes(".//*[local-name()='t']") | ForEach-Object { $_.InnerText }
        $items.Add(($parts -join "")) | Out-Null
    }

    return $items.ToArray()
}

function Get-WorksheetEntryName {
    param(
        [System.IO.Compression.ZipArchive]$Archive,
        [string]$PreferredSheetName
    )

    $workbookText = Read-ZipEntryText -Archive $Archive -EntryName "xl/workbook.xml"
    $relsText = Read-ZipEntryText -Archive $Archive -EntryName "xl/_rels/workbook.xml.rels"

    if ([string]::IsNullOrWhiteSpace($workbookText) -or [string]::IsNullOrWhiteSpace($relsText)) {
        throw "Could not locate workbook metadata in '$WorkbookPath'."
    }

    [xml]$workbookXml = $workbookText
    [xml]$relsXml = $relsText

    $relsById = @{}
    foreach ($relationship in $relsXml.Relationships.Relationship) {
        $target = [string]$relationship.Target
        if ($target.StartsWith("/")) {
            $relsById[[string]$relationship.Id] = $target.TrimStart("/")
        }
        elseif ($target.StartsWith("xl/")) {
            $relsById[[string]$relationship.Id] = $target
        }
        else {
            $relsById[[string]$relationship.Id] = "xl/$target"
        }
    }

    $sheetNode = $null
    $workbookNode = [System.Xml.XmlNode]$workbookXml
    foreach ($candidate in $workbookNode.SelectNodes("//*[local-name()='sheets']/*[local-name()='sheet']")) {
        if ([string]$candidate.name -eq $PreferredSheetName) {
            $sheetNode = $candidate
            break
        }
    }

    if ($null -eq $sheetNode) {
        throw "Worksheet '$PreferredSheetName' was not found in '$WorkbookPath'."
    }

    $relationshipId = $sheetNode.GetAttribute("id", $RelationshipNamespace)
    return $relsById[$relationshipId]
}

function Get-CellValue {
    param(
        [System.Xml.XmlNode]$Cell,
        [string[]]$SharedStrings
    )

    $cellNode = [System.Xml.XmlNode]$Cell
    $cellType = $cellNode.GetAttribute("t")

    if ($cellType -eq "inlineStr") {
        $parts = $cellNode.SelectNodes(".//*[local-name()='t']") | ForEach-Object { $_.InnerText }
        return $parts -join ""
    }

    $valueNode = $cellNode.SelectSingleNode("./*[local-name()='v']")
    if ($null -eq $valueNode) {
        return ""
    }

    $value = $valueNode.InnerText
    if ($cellType -eq "s") {
        $index = [int]$value
        if ($index -ge 0 -and $index -lt $SharedStrings.Count) {
            return $SharedStrings[$index]
        }

        return ""
    }

    return $value
}

function Get-ColumnNameFromReference {
    param([string]$Reference)

    return ($Reference -replace "\d", "")
}

function Convert-ColumnNameToIndex {
    param([string]$ColumnName)

    $index = 0
    foreach ($character in $ColumnName.ToUpperInvariant().ToCharArray()) {
        $index = ($index * 26) + ([int][char]$character - [int][char]'A' + 1)
    }

    return $index
}

function Get-OrderedColumnsFromHeaderRow {
    param([hashtable]$HeaderCells)

    return @($HeaderCells.Keys | Sort-Object { Convert-ColumnNameToIndex -ColumnName $_ })
}

function Get-SpanStringFromColumns {
    param([string[]]$OrderedColumns)

    if ($null -eq $OrderedColumns -or $OrderedColumns.Count -eq 0) {
        return "1:1"
    }

    $lastColumn = $OrderedColumns[-1]
    return "1:$(Convert-ColumnNameToIndex -ColumnName $lastColumn)"
}

function Get-HeaderMap {
    param([hashtable]$HeaderCells)

    $map = @{}
    foreach ($column in $HeaderCells.Keys) {
        $map[[string]$HeaderCells[$column]] = $column
    }

    return $map
}

function Get-HeaderColumnOrDefault {
    param(
        [hashtable]$HeaderMap,
        [string]$HeaderName,
        [string]$DefaultColumn
    )

    if ($HeaderMap.ContainsKey($HeaderName)) {
        return [string]$HeaderMap[$HeaderName]
    }

    return $DefaultColumn
}

function Get-StuckReasonFromText {
    param([string]$Text)

    if ([string]::IsNullOrWhiteSpace($Text)) {
        return ""
    }

    $reasons = New-Object System.Collections.Generic.List[string]
    $instanceOcids = [regex]::Matches($Text, "ocid1\.instance\.[A-Za-z0-9._-]+", [System.Text.RegularExpressions.RegexOptions]::IgnoreCase) |
        ForEach-Object { $_.Value } |
        Sort-Object -Unique

    foreach ($instanceOcid in $instanceOcids) {
        $reason = ""
        if ($InstanceReasonOverrides.ContainsKey($instanceOcid)) {
            $reason = $InstanceReasonOverrides[$instanceOcid]
        }
        elseif ($instanceOcid -match "ocid1\.instance\.oc1\.eu-frankfurt-1\.") {
            $reason = "Out of capacity error"
        }
        elseif ($instanceOcid -match "ocid1\.instance\.oc1\.iad\.") {
            $reason = "Bad HV"
        }

        if (-not [string]::IsNullOrWhiteSpace($reason) -and -not ($reasons -contains $reason)) {
            $reasons.Add($reason) | Out-Null
        }
    }

    if ($reasons.Count -gt 0) {
        return ($reasons.ToArray() -join "; ")
    }

    return ""
}

function Join-UniqueReasons {
    param([string[]]$Values)

    $reasons = New-Object System.Collections.Generic.List[string]
    foreach ($value in $Values) {
        if ([string]::IsNullOrWhiteSpace($value)) {
            continue
        }

        foreach ($reason in ($value -split "\s*;\s*" | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })) {
            if (-not ($reasons -contains $reason)) {
                $reasons.Add($reason) | Out-Null
            }
        }
    }

    if ($reasons.Count -eq 0) {
        return ""
    }

    return ($reasons.ToArray() -join "; ")
}

function Get-ResolvedStuckReason {
    param(
        [string]$Text,
        [string]$ExplicitReason = "",
        [string]$ExistingReasons = ""
    )

    return Join-UniqueReasons -Values @(
        $ExistingReasons
        $ExplicitReason
        (Get-StuckReasonFromText -Text $Text)
    )
}

function Get-SheetRows {
    param(
        [xml]$SheetXml,
        [string[]]$SharedStrings
    )

    $rows = New-Object System.Collections.Generic.List[object]

    $sheetNode = [System.Xml.XmlNode]$SheetXml
    foreach ($rowNode in $sheetNode.SelectNodes("//*[local-name()='sheetData']/*[local-name()='row']")) {
        $rowXmlNode = [System.Xml.XmlNode]$rowNode
        $cellsByColumn = @{}
        foreach ($cell in $rowXmlNode.SelectNodes("./*[local-name()='c']")) {
            $reference = [string]$cell.r
            $column = Get-ColumnNameFromReference -Reference $reference
            $cellsByColumn[$column] = Get-CellValue -Cell $cell -SharedStrings $SharedStrings
        }

        $rows.Add([PSCustomObject]@{
                Node = $rowXmlNode
                RowNumber = [int]$rowXmlNode.r
                Cells = $cellsByColumn
            }) | Out-Null
    }

    return $rows
}

function New-InlineCellNode {
    param(
        [xml]$SheetXml,
        [string]$Reference,
        [string]$Value
    )

    $cellNode = $SheetXml.CreateElement("c", $SpreadsheetNamespace)
    $null = $cellNode.SetAttribute("r", $Reference)
    $null = $cellNode.SetAttribute("t", "inlineStr")

    $isNode = $SheetXml.CreateElement("is", $SpreadsheetNamespace)
    $textNode = $SheetXml.CreateElement("t", $SpreadsheetNamespace)
    $spaceAttribute = $SheetXml.CreateAttribute("xml", "space", $XmlNamespace)
    $spaceAttribute.Value = "preserve"
    $textNode.Attributes.Append($spaceAttribute) | Out-Null
    $textNode.InnerText = [string]$Value

    $isNode.AppendChild($textNode) | Out-Null
    $cellNode.AppendChild($isNode) | Out-Null

    return $cellNode
}

function Set-RowCells {
    param(
        [xml]$SheetXml,
        [System.Xml.XmlNode]$RowNode,
        [int]$RowNumber,
        [hashtable]$ValuesByColumn,
        [string[]]$OrderedColumns,
        [string]$Spans
    )

    $rowXmlNode = [System.Xml.XmlNode]$RowNode
    foreach ($cell in @($rowXmlNode.SelectNodes("./*[local-name()='c']"))) {
        $null = $rowXmlNode.RemoveChild($cell)
    }

    $null = $rowXmlNode.SetAttribute("r", [string]$RowNumber)
    if (-not [string]::IsNullOrWhiteSpace($Spans)) {
        $null = $rowXmlNode.SetAttribute("spans", $Spans)
    }

    if ($null -eq $OrderedColumns -or $OrderedColumns.Count -eq 0) {
        $OrderedColumns = @($ValuesByColumn.Keys | Sort-Object { Convert-ColumnNameToIndex -ColumnName $_ })
    }

    foreach ($column in $OrderedColumns) {
        if (-not $ValuesByColumn.ContainsKey($column)) {
            continue
        }

        $cellNode = New-InlineCellNode -SheetXml $SheetXml -Reference "$column$RowNumber" -Value ([string]$ValuesByColumn[$column])
        $rowXmlNode.AppendChild($cellNode) | Out-Null
    }
}

function Get-CellTextOrBlank {
    param(
        [hashtable]$Cells,
        [string]$Column
    )

    if ($Cells.ContainsKey($Column)) {
        return [string]$Cells[$Column]
    }

    return ""
}

function Get-RowValuesByColumns {
    param(
        [hashtable]$Cells,
        [string[]]$OrderedColumns
    )

    $values = @{}
    foreach ($column in $OrderedColumns) {
        $values[$column] = Get-CellTextOrBlank -Cells $Cells -Column $column
    }

    return $values
}

function Ensure-Dimension {
    param(
        [xml]$SheetXml,
        [string]$LastColumn,
        [int]$LastRow
    )

    $sheetNode = [System.Xml.XmlNode]$SheetXml
    $dimensionNode = $sheetNode.SelectSingleNode("//*[local-name()='dimension']")
    if ($null -eq $dimensionNode) {
        return
    }

    $null = $dimensionNode.SetAttribute("ref", "A1:$LastColumn$LastRow")
}

function Convert-XmlDocumentToText {
    param([xml]$XmlDocument)

    return "<?xml version=`"1.0`" encoding=`"UTF-8`" standalone=`"yes`"?>`r`n$($XmlDocument.DocumentElement.OuterXml)"
}

function Copy-EntryBytes {
    param(
        [System.IO.Compression.ZipArchiveEntry]$SourceEntry,
        [System.IO.Compression.ZipArchive]$DestinationArchive
    )

    $destinationEntry = $DestinationArchive.CreateEntry($SourceEntry.FullName)
    $sourceStream = $SourceEntry.Open()
    $destinationStream = $destinationEntry.Open()

    try {
        $sourceStream.CopyTo($destinationStream)
    }
    finally {
        $destinationStream.Dispose()
        $sourceStream.Dispose()
    }
}

function Write-StringEntry {
    param(
        [System.IO.Compression.ZipArchive]$DestinationArchive,
        [string]$EntryName,
        [string]$Content
    )

    $entry = $DestinationArchive.CreateEntry($EntryName)
    $stream = $entry.Open()
    $writer = New-Object System.IO.StreamWriter($stream, [System.Text.UTF8Encoding]::new($false))
    try {
        $writer.Write($Content)
    }
    finally {
        $writer.Dispose()
    }
}

function Copy-FileWithReadShare {
    param(
        [string]$SourcePath,
        [string]$DestinationPath
    )

    $sourceStream = [System.IO.File]::Open($SourcePath, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite)
    $destinationStream = [System.IO.File]::Open($DestinationPath, [System.IO.FileMode]::Create, [System.IO.FileAccess]::Write, [System.IO.FileShare]::None)

    try {
        $sourceStream.CopyTo($destinationStream)
    }
    finally {
        $destinationStream.Dispose()
        $sourceStream.Dispose()
    }
}

$SrNumber = $SrNumber.Trim()
$InstanceOCID = $InstanceOCID.Trim()
$StuckReason = $StuckReason.Trim()

if ([string]::IsNullOrWhiteSpace($SrNumber)) {
    throw "SrNumber cannot be blank."
}

if ([string]::IsNullOrWhiteSpace($InstanceOCID)) {
    throw "InstanceOCID cannot be blank."
}

if (-not (Test-Path -LiteralPath $WorkbookPath)) {
    throw "Workbook '$WorkbookPath' was not found."
}

$WorkbookPath = (Resolve-Path -LiteralPath $WorkbookPath).Path

if ([string]::IsNullOrWhiteSpace($OutputPath)) {
    $OutputPath = $WorkbookPath
}
elseif (-not [System.IO.Path]::IsPathRooted($OutputPath)) {
    $OutputPath = Join-Path (Get-Location) $OutputPath
}

$OutputPath = [System.IO.Path]::GetFullPath($OutputPath)
$sourceDirectory = Split-Path -Parent $WorkbookPath
$outputDirectory = Split-Path -Parent $OutputPath
if (-not [string]::IsNullOrWhiteSpace($outputDirectory) -and -not (Test-Path -LiteralPath $outputDirectory)) {
    New-Item -ItemType Directory -Path $outputDirectory -Force | Out-Null
}

$isInPlaceUpdate = [string]::Equals($WorkbookPath, $OutputPath, [System.StringComparison]::OrdinalIgnoreCase)
$backupTimestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$sourceFilename = [System.IO.Path]::GetFileNameWithoutExtension($WorkbookPath)
$sourceExtension = [System.IO.Path]::GetExtension($WorkbookPath)
$outputFilename = [System.IO.Path]::GetFileNameWithoutExtension($OutputPath)
$outputExtension = [System.IO.Path]::GetExtension($OutputPath)
$backupPath = ""
if ($isInPlaceUpdate) {
    $backupPath = Join-Path $sourceDirectory "$sourceFilename.backup_$backupTimestamp$sourceExtension"
    Copy-FileWithReadShare -SourcePath $WorkbookPath -DestinationPath $backupPath
}

$sourceStream = [System.IO.File]::Open($WorkbookPath, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite)
$sourceArchive = New-Object System.IO.Compression.ZipArchive($sourceStream, [System.IO.Compression.ZipArchiveMode]::Read, $false)
try {
    $sharedStrings = Get-SharedStrings -Archive $sourceArchive

    $ocidSheetEntry = Get-WorksheetEntryName -Archive $sourceArchive -PreferredSheetName "SR OCIDs"
    $summarySheetEntry = Get-WorksheetEntryName -Archive $sourceArchive -PreferredSheetName $SummarySheetName

    [xml]$ocidSheetXml = Read-ZipEntryText -Archive $sourceArchive -EntryName $ocidSheetEntry
    [xml]$summarySheetXml = Read-ZipEntryText -Archive $sourceArchive -EntryName $summarySheetEntry

    $ocidRows = Get-SheetRows -SheetXml $ocidSheetXml -SharedStrings $sharedStrings
    $summaryRows = Get-SheetRows -SheetXml $summarySheetXml -SharedStrings $sharedStrings

    $ocidHeaderRow = $ocidRows | Select-Object -First 1
    $summaryHeaderRow = $summaryRows | Select-Object -First 1

    $ocidColumns = Get-OrderedColumnsFromHeaderRow -HeaderCells $ocidHeaderRow.Cells
    $summaryColumns = Get-OrderedColumnsFromHeaderRow -HeaderCells $summaryHeaderRow.Cells

    $ocidHeaderMap = Get-HeaderMap -HeaderCells $ocidHeaderRow.Cells
    $summaryHeaderMap = Get-HeaderMap -HeaderCells $summaryHeaderRow.Cells

    $ocidSpan = Get-SpanStringFromColumns -OrderedColumns $ocidColumns
    $summarySpan = Get-SpanStringFromColumns -OrderedColumns $summaryColumns

    $ocidSrColumn = Get-HeaderColumnOrDefault -HeaderMap $ocidHeaderMap -HeaderName "SR" -DefaultColumn "A"
    $ocidCreatedColumn = Get-HeaderColumnOrDefault -HeaderMap $ocidHeaderMap -HeaderName "SRCreatedDate" -DefaultColumn "B"
    $ocidInstanceColumn = Get-HeaderColumnOrDefault -HeaderMap $ocidHeaderMap -HeaderName "InstanceOCID" -DefaultColumn "C"
    $ocidReasonColumn = if ($ocidHeaderMap.ContainsKey($ReasonHeaderName)) { [string]$ocidHeaderMap[$ReasonHeaderName] } else { $null }

    $summarySrColumn = Get-HeaderColumnOrDefault -HeaderMap $summaryHeaderMap -HeaderName "SR" -DefaultColumn "A"
    $summaryOcidsColumn = Get-HeaderColumnOrDefault -HeaderMap $summaryHeaderMap -HeaderName "OCID(s)" -DefaultColumn "I"
    $summaryReasonColumn = if ($summaryHeaderMap.ContainsKey($ReasonHeaderName)) { [string]$summaryHeaderMap[$ReasonHeaderName] } else { $null }

    $ocidRowAdded = $false
    $existingOcidRow = $ocidRows | Where-Object {
        $_.Cells.ContainsKey($ocidSrColumn) -and $_.Cells.ContainsKey($ocidInstanceColumn) -and
        $_.Cells[$ocidSrColumn] -eq $SrNumber -and $_.Cells[$ocidInstanceColumn] -eq $InstanceOCID
    } | Select-Object -First 1

    if ($null -eq $existingOcidRow) {
        $lastOcidRow = $ocidRows | Select-Object -Last 1
        $newOcidRowNumber = $lastOcidRow.RowNumber + 1
        $newOcidRowNode = $lastOcidRow.Node.CloneNode($true)
        $newOcidRowValues = @{}
        foreach ($column in $ocidColumns) {
            $newOcidRowValues[$column] = ""
        }

        $newOcidRowValues[$ocidSrColumn] = $SrNumber
        $newOcidRowValues[$ocidCreatedColumn] = ""
        $newOcidRowValues[$ocidInstanceColumn] = $InstanceOCID
        if (-not [string]::IsNullOrWhiteSpace($ocidReasonColumn)) {
            $newOcidRowValues[$ocidReasonColumn] = Get-ResolvedStuckReason -Text $InstanceOCID -ExplicitReason $StuckReason
        }

        Set-RowCells -SheetXml $ocidSheetXml -RowNode $newOcidRowNode -RowNumber $newOcidRowNumber -ValuesByColumn $newOcidRowValues -OrderedColumns $ocidColumns -Spans $ocidSpan
    }

    $ocidSheetData = $ocidSheetXml.SelectSingleNode("//*[local-name()='sheetData']")

    if ($null -eq $existingOcidRow) {
        $ocidSheetData.AppendChild($newOcidRowNode) | Out-Null
        Ensure-Dimension -SheetXml $ocidSheetXml -LastColumn $ocidColumns[-1] -LastRow $newOcidRowNumber
        $ocidRowAdded = $true
    }

    $summaryRowAdded = $false
    $summaryRowUpdated = $false
    $summaryExistingRow = $summaryRows | Where-Object {
        $_.Cells.ContainsKey($summarySrColumn) -and $_.Cells[$summarySrColumn] -eq $SrNumber
    } | Select-Object -First 1

    if ($null -eq $summaryExistingRow) {
        $lastSummaryRow = $summaryRows | Select-Object -Last 1
        $newSummaryRowNumber = $lastSummaryRow.RowNumber + 1
        $newSummaryRowNode = $lastSummaryRow.Node.CloneNode($true)
        $newSummaryRowValues = @{}
        foreach ($column in $summaryColumns) {
            $newSummaryRowValues[$column] = ""
        }

        $newSummaryRowValues[$summarySrColumn] = $SrNumber
        $newSummaryRowValues[$summaryOcidsColumn] = $InstanceOCID
        if (-not [string]::IsNullOrWhiteSpace($summaryReasonColumn)) {
            $newSummaryRowValues[$summaryReasonColumn] = Get-ResolvedStuckReason -Text $InstanceOCID -ExplicitReason $StuckReason
        }

        Set-RowCells -SheetXml $summarySheetXml -RowNode $newSummaryRowNode -RowNumber $newSummaryRowNumber -ValuesByColumn $newSummaryRowValues -OrderedColumns $summaryColumns -Spans $summarySpan

        $summarySheetData = $summarySheetXml.SelectSingleNode("//*[local-name()='sheetData']")
        $summarySheetData.AppendChild($newSummaryRowNode) | Out-Null
        Ensure-Dimension -SheetXml $summarySheetXml -LastColumn $summaryColumns[-1] -LastRow $newSummaryRowNumber
        $summaryRowAdded = $true
    }
    else {
        $currentOcids = @()
        if ($summaryExistingRow.Cells.ContainsKey($summaryOcidsColumn)) {
            $currentOcids = @(
                $summaryExistingRow.Cells[$summaryOcidsColumn] -split "\s*;\s*" |
                Where-Object { -not [string]::IsNullOrWhiteSpace($_) }
            )
        }

        if (-not ($currentOcids -contains $InstanceOCID)) {
            $combinedOcids = @($currentOcids + $InstanceOCID) -join "; "
            $summaryRowValues = Get-RowValuesByColumns -Cells $summaryExistingRow.Cells -OrderedColumns $summaryColumns
            $summaryRowValues[$summaryOcidsColumn] = $combinedOcids
            if (-not [string]::IsNullOrWhiteSpace($summaryReasonColumn)) {
                $existingReasons = ""
                if ($summaryExistingRow.Cells.ContainsKey($summaryReasonColumn)) {
                    $existingReasons = [string]$summaryExistingRow.Cells[$summaryReasonColumn]
                }

                $summaryRowValues[$summaryReasonColumn] = Get-ResolvedStuckReason -Text $combinedOcids -ExplicitReason $StuckReason -ExistingReasons $existingReasons
            }

            Set-RowCells -SheetXml $summarySheetXml -RowNode $summaryExistingRow.Node -RowNumber $summaryExistingRow.RowNumber -ValuesByColumn $summaryRowValues -OrderedColumns $summaryColumns -Spans $summarySpan
            $summaryRowUpdated = $true
        }
    }

    $replacementEntries = @{
        $ocidSheetEntry = Convert-XmlDocumentToText -XmlDocument $ocidSheetXml
        $summarySheetEntry = Convert-XmlDocumentToText -XmlDocument $summarySheetXml
    }

    $tempPath = Join-Path $outputDirectory "$outputFilename.manual_update_$backupTimestamp$outputExtension"
    $destinationStream = [System.IO.File]::Open($tempPath, [System.IO.FileMode]::Create)
    try {
        $destinationArchive = New-Object System.IO.Compression.ZipArchive($destinationStream, [System.IO.Compression.ZipArchiveMode]::Create, $false)
        try {
            foreach ($entry in $sourceArchive.Entries) {
                if ($replacementEntries.ContainsKey($entry.FullName)) {
                    Write-StringEntry -DestinationArchive $destinationArchive -EntryName $entry.FullName -Content $replacementEntries[$entry.FullName]
                }
                else {
                    Copy-EntryBytes -SourceEntry $entry -DestinationArchive $destinationArchive
                }
            }
        }
        finally {
            $destinationArchive.Dispose()
        }
    }
    finally {
        $destinationStream.Dispose()
    }
}
finally {
    $sourceArchive.Dispose()
    $sourceStream.Dispose()
}

Move-Item -LiteralPath $tempPath -Destination $OutputPath -Force

[PSCustomObject]@{
    WorkbookPath = (Resolve-Path -LiteralPath $OutputPath).Path
    BackupPath = if ([string]::IsNullOrWhiteSpace($backupPath)) { "" } else { (Resolve-Path -LiteralPath $backupPath).Path }
    SourceWorkbookPath = $WorkbookPath
    SrNumber = $SrNumber
    InstanceOCID = $InstanceOCID
    StuckReason = $StuckReason
    OcidRowAdded = $ocidRowAdded
    SummaryRowAdded = $summaryRowAdded
    SummaryRowUpdated = $summaryRowUpdated
} | ConvertTo-Json -Depth 4
