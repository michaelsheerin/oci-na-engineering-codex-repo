param(
    [string]$DetailsJsonPath = (Join-Path (Get-Location) "..\outputs\sr_details.json"),
    [string]$OutputPath = (Join-Path (Get-Location) "..\outputs\sr_summary.xlsx")
)

$ErrorActionPreference = "Stop"

Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

function Convert-ColumnIndexToName {
    param([int]$Index)

    $name = ""
    $current = $Index
    while ($current -gt 0) {
        $current--
        $name = [char](65 + ($current % 26)) + $name
        $current = [math]::Floor($current / 26)
    }
    return $name
}

function New-InlineCellXml {
    param(
        [string]$Reference,
        [string]$Value
    )

    $escapedValue = [System.Security.SecurityElement]::Escape([string]$Value)
    if ($null -eq $escapedValue) {
        $escapedValue = ""
    }

    return "<c r=`"$Reference`" t=`"inlineStr`"><is><t xml:space=`"preserve`">$escapedValue</t></is></c>"
}

function New-RowXml {
    param(
        [int]$RowNumber,
        [object[]]$Values
    )

    $cells = for ($i = 0; $i -lt $Values.Count; $i++) {
        $columnName = Convert-ColumnIndexToName -Index ($i + 1)
        New-InlineCellXml -Reference ($columnName + $RowNumber) -Value ([string]$Values[$i])
    }

    return "<row r=`"$RowNumber`">$($cells -join '')</row>"
}

function New-WorksheetXml {
    param([object[]]$Rows)

    $maxColumns = 1
    foreach ($row in $Rows) {
        if ($row.Count -gt $maxColumns) {
            $maxColumns = $row.Count
        }
    }

    $lastRow = [math]::Max(1, $Rows.Count)
    $lastColumn = Convert-ColumnIndexToName -Index $maxColumns
    $rowXml = New-Object System.Collections.Generic.List[string]
    $excelRowNumber = 1
    foreach ($row in $Rows) {
        $rowXml.Add((New-RowXml -RowNumber $excelRowNumber -Values @($row)))
        $excelRowNumber++
    }

    return @"
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <dimension ref="A1:$lastColumn$lastRow"/>
  <sheetViews>
    <sheetView workbookViewId="0">
      <pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/>
    </sheetView>
  </sheetViews>
  <sheetFormatPr defaultRowHeight="15"/>
  <cols>
    <col min="1" max="1" width="16" customWidth="1"/>
    <col min="2" max="2" width="45" customWidth="1"/>
    <col min="3" max="4" width="22" customWidth="1"/>
    <col min="5" max="5" width="95" customWidth="1"/>
    <col min="6" max="9" width="22" customWidth="1"/>
    <col min="10" max="10" width="28" customWidth="1"/>
  </cols>
  <sheetData>
    $($rowXml -join "`n    ")
  </sheetData>
  <autoFilter ref="A1:$lastColumn$lastRow"/>
</worksheet>
"@
}

function Add-ZipEntry {
    param(
        [System.IO.Compression.ZipArchive]$Archive,
        [string]$EntryName,
        [string]$Content
    )

    $entry = $Archive.CreateEntry($EntryName)
    $stream = $entry.Open()
    $writer = New-Object System.IO.StreamWriter($stream, [System.Text.UTF8Encoding]::new($false))
    try {
        $writer.Write($Content)
    }
    finally {
        $writer.Dispose()
    }
}

function Write-Workbook {
    param(
        [string]$OutputPath,
        [object[]]$Sheets
    )

    $overrides = New-Object System.Collections.Generic.List[string]
    $sheetEntries = New-Object System.Collections.Generic.List[string]
    $sheetRelationships = New-Object System.Collections.Generic.List[string]

    for ($i = 0; $i -lt $Sheets.Count; $i++) {
        $sheetNumber = $i + 1
        $sheetName = [System.Security.SecurityElement]::Escape([string]$Sheets[$i].Name)
        $sheetEntries.Add("    <sheet name=`"$sheetName`" sheetId=`"$sheetNumber`" r:id=`"rId$sheetNumber`"/>")
        $sheetRelationships.Add("  <Relationship Id=`"rId$sheetNumber`" Type=`"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet`" Target=`"worksheets/sheet$sheetNumber.xml`"/>")
        $overrides.Add("  <Override PartName=`"/xl/worksheets/sheet$sheetNumber.xml`" ContentType=`"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml`"/>")
    }

    $contentTypesXml = @"
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
$($overrides -join "`n")
</Types>
"@

    $rootRelsXml = @"
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>
"@

    $workbookXml = @"
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheets>
$($sheetEntries -join "`n")
  </sheets>
</workbook>
"@

    $workbookRelsXml = @"
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
$($sheetRelationships -join "`n")
</Relationships>
"@

    $outputDirectory = Split-Path -Parent $OutputPath
    if (-not [string]::IsNullOrWhiteSpace($outputDirectory) -and -not (Test-Path -LiteralPath $outputDirectory)) {
        New-Item -ItemType Directory -Path $outputDirectory | Out-Null
    }

    $fileStream = [System.IO.File]::Open($OutputPath, [System.IO.FileMode]::Create)
    try {
        $archive = New-Object System.IO.Compression.ZipArchive($fileStream, [System.IO.Compression.ZipArchiveMode]::Create, $false)
        try {
            Add-ZipEntry -Archive $archive -EntryName "[Content_Types].xml" -Content $contentTypesXml
            Add-ZipEntry -Archive $archive -EntryName "_rels/.rels" -Content $rootRelsXml
            Add-ZipEntry -Archive $archive -EntryName "xl/workbook.xml" -Content $workbookXml
            Add-ZipEntry -Archive $archive -EntryName "xl/_rels/workbook.xml.rels" -Content $workbookRelsXml
            for ($i = 0; $i -lt $Sheets.Count; $i++) {
                Add-ZipEntry -Archive $archive -EntryName "xl/worksheets/sheet$($i + 1).xml" -Content $Sheets[$i].Xml
            }
        }
        finally {
            $archive.Dispose()
        }
    }
    finally {
        $fileStream.Dispose()
    }
}

function Get-DateDifferenceDays {
    param(
        [string]$StartDate,
        [string]$EndDate
    )

    if ([string]::IsNullOrWhiteSpace($StartDate) -or [string]::IsNullOrWhiteSpace($EndDate)) {
        return ""
    }

    try {
        $start = [System.DateTimeOffset]::Parse($StartDate)
        $end = [System.DateTimeOffset]::Parse($EndDate)
        return [math]::Round(($end - $start).TotalDays, 2).ToString([System.Globalization.CultureInfo]::InvariantCulture)
    }
    catch {
        return ""
    }
}

$detailsPath = [System.IO.Path]::GetFullPath((Join-Path (Get-Location) $DetailsJsonPath))
$outputPathFull = [System.IO.Path]::GetFullPath((Join-Path (Get-Location) $OutputPath))
$details = Get-Content -Path $detailsPath -Raw | ConvertFrom-Json

$rowsBySr = @{}
foreach ($row in @($details.rows)) {
    $rowsBySr[[string]$row.SR] = $row
}

$errorsBySr = @{}
foreach ($errorRow in @($details.errors)) {
    $errorsBySr[[string]$errorRow.SR] = [string]$errorRow.error
}

$summaryRows = @(
    ,@("SR Number", "Task / Notes", "Create Date", "Last Update Date", "Days Between Create and Update", "Description of Issue", "Severity", "Status", "Raised By", "SR Owner", "Fetch Status")
)

foreach ($srNumber in @($details.requested)) {
    if ($rowsBySr.ContainsKey([string]$srNumber)) {
        $row = $rowsBySr[[string]$srNumber]
        $summaryRows += ,@(
            [string]$row.SR,
            [string]$row.SRHeading,
            [string]$row.CreationDate,
            [string]$row.LastUpdateDate,
            (Get-DateDifferenceDays -StartDate ([string]$row.CreationDate) -EndDate ([string]$row.LastUpdateDate)),
            [string]$row.IssueDescription,
            [string]$row.Severity,
            [string]$row.Status,
            [string]$row.CreatedBy,
            [string]$row.SROwner,
            "Fetched"
        )
    }
    else {
        $errorText = if ($errorsBySr.ContainsKey([string]$srNumber)) { $errorsBySr[[string]$srNumber] } else { "Not fetched" }
        $summaryRows += ,@([string]$srNumber, "", "", "", "", "", "", "", "", "", "Fetch failed: $errorText")
    }
}

$issueRows = @(
    ,@("SR Number", "Fetch Error")
)
foreach ($errorRow in @($details.errors)) {
    $issueRows += ,@([string]$errorRow.SR, [string]$errorRow.error)
}

$sheets = @(
    [PSCustomObject]@{
        Name = "Requested SR Summary"
        Xml = New-WorksheetXml -Rows $summaryRows
    },
    [PSCustomObject]@{
        Name = "Fetch Issues"
        Xml = New-WorksheetXml -Rows $issueRows
    }
)

Write-Workbook -OutputPath $outputPathFull -Sheets $sheets

[PSCustomObject]@{
    WorkbookPath = $outputPathFull
    RequestedSrCount = @($details.requested).Count
    FetchedSrCount = @($details.rows).Count
    ErrorCount = @($details.errors).Count
} | ConvertTo-Json
