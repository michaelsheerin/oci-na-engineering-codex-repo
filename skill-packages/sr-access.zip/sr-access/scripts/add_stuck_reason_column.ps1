param(
    [string]$WorkbookPath = (Join-Path (Get-Location) "sr_ocids_date.xlsx"),
    [string]$SummarySheetName = "Requested SR Summary"
)

$ErrorActionPreference = "Stop"

Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

$SpreadsheetNamespace = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
$RelationshipNamespace = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
$XmlNamespace = "http://www.w3.org/XML/1998/namespace"
$ReasonHeaderName = "Why was it in stuck state"
$InstanceReasonOverrides = @{
    # Add team-specific one-off OCID reason overrides here if needed.
    # Example: "example-instance-ocid" = "Unhealthy HV"
}

function Read-ZipEntryText {
    param(
        [System.IO.Compression.ZipArchive]$Archive,
        [string]$EntryName
    )

    $entry = $Archive.GetEntry($EntryName)
    if ($null -eq $entry) {
        return $null
    }

    $reader = New-Object System.IO.StreamReader($entry.Open())
    try {
        return $reader.ReadToEnd()
    }
    finally {
        $reader.Dispose()
    }
}

function Get-SharedStrings {
    param([System.IO.Compression.ZipArchive]$Archive)

    $text = Read-ZipEntryText -Archive $Archive -EntryName "xl/sharedStrings.xml"
    if ([string]::IsNullOrWhiteSpace($text)) {
        return @()
    }

    [xml]$xml = $text
    $items = New-Object System.Collections.Generic.List[string]
    $xmlNode = [System.Xml.XmlNode]$xml
    foreach ($si in $xmlNode.SelectNodes("//*[local-name()='si']")) {
        $siNode = [System.Xml.XmlNode]$si
        $parts = $siNode.SelectNodes(".//*[local-name()='t']") | ForEach-Object { $_.InnerText }
        $items.Add(($parts -join "")) | Out-Null
    }

    return $items.ToArray()
}

function Get-WorksheetEntryName {
    param(
        [System.IO.Compression.ZipArchive]$Archive,
        [string]$PreferredSheetName
    )

    $workbookText = Read-ZipEntryText -Archive $Archive -EntryName "xl/workbook.xml"
    $relsText = Read-ZipEntryText -Archive $Archive -EntryName "xl/_rels/workbook.xml.rels"

    if ([string]::IsNullOrWhiteSpace($workbookText) -or [string]::IsNullOrWhiteSpace($relsText)) {
        throw "Could not locate workbook metadata in '$WorkbookPath'."
    }

    [xml]$workbookXml = $workbookText
    [xml]$relsXml = $relsText

    $relsById = @{}
    foreach ($relationship in $relsXml.Relationships.Relationship) {
        $target = [string]$relationship.Target
        if ($target.StartsWith("/")) {
            $relsById[[string]$relationship.Id] = $target.TrimStart("/")
        }
        elseif ($target.StartsWith("xl/")) {
            $relsById[[string]$relationship.Id] = $target
        }
        else {
            $relsById[[string]$relationship.Id] = "xl/$target"
        }
    }

    $sheetNode = $null
    $workbookNode = [System.Xml.XmlNode]$workbookXml
    foreach ($candidate in $workbookNode.SelectNodes("//*[local-name()='sheets']/*[local-name()='sheet']")) {
        if ([string]$candidate.name -eq $PreferredSheetName) {
            $sheetNode = $candidate
            break
        }
    }

    if ($null -eq $sheetNode) {
        throw "Worksheet '$PreferredSheetName' was not found in '$WorkbookPath'."
    }

    $relationshipId = $sheetNode.GetAttribute("id", $RelationshipNamespace)
    return $relsById[$relationshipId]
}

function Get-CellValue {
    param(
        [System.Xml.XmlNode]$Cell,
        [string[]]$SharedStrings
    )

    $cellNode = [System.Xml.XmlNode]$Cell
    $cellType = $cellNode.GetAttribute("t")

    if ($cellType -eq "inlineStr") {
        $parts = $cellNode.SelectNodes(".//*[local-name()='t']") | ForEach-Object { $_.InnerText }
        return $parts -join ""
    }

    $valueNode = $cellNode.SelectSingleNode("./*[local-name()='v']")
    if ($null -eq $valueNode) {
        return ""
    }

    $value = $valueNode.InnerText
    if ($cellType -eq "s") {
        $index = [int]$value
        if ($index -ge 0 -and $index -lt $SharedStrings.Count) {
            return $SharedStrings[$index]
        }

        return ""
    }

    return $value
}

function Get-ColumnNameFromReference {
    param([string]$Reference)

    return ($Reference -replace "\d", "")
}

function Convert-ColumnNameToIndex {
    param([string]$ColumnName)

    $index = 0
    foreach ($character in $ColumnName.ToUpperInvariant().ToCharArray()) {
        $index = ($index * 26) + ([int][char]$character - [int][char]'A' + 1)
    }

    return $index
}

function Convert-ColumnIndexToName {
    param([int]$ColumnIndex)

    $name = ""
    $current = $ColumnIndex
    while ($current -gt 0) {
        $current--
        $name = [char]([int][char]'A' + ($current % 26)) + $name
        $current = [math]::Floor($current / 26)
    }

    return $name
}

function Get-OrderedColumnsFromHeaderRow {
    param([hashtable]$HeaderCells)

    return @($HeaderCells.Keys | Sort-Object { Convert-ColumnNameToIndex -ColumnName $_ })
}

function Get-SpanStringFromColumns {
    param([string[]]$OrderedColumns)

    if ($null -eq $OrderedColumns -or $OrderedColumns.Count -eq 0) {
        return "1:1"
    }

    $lastColumn = $OrderedColumns[-1]
    return "1:$(Convert-ColumnNameToIndex -ColumnName $lastColumn)"
}

function Get-HeaderMap {
    param([hashtable]$HeaderCells)

    $map = @{}
    foreach ($column in $HeaderCells.Keys) {
        $map[[string]$HeaderCells[$column]] = $column
    }

    return $map
}

function Get-HeaderColumnOrDefault {
    param(
        [hashtable]$HeaderMap,
        [string]$HeaderName,
        [string]$DefaultColumn
    )

    if ($HeaderMap.ContainsKey($HeaderName)) {
        return [string]$HeaderMap[$HeaderName]
    }

    return $DefaultColumn
}

function Get-StuckReasonFromText {
    param([string]$Text)

    if ([string]::IsNullOrWhiteSpace($Text)) {
        return ""
    }

    $reasons = New-Object System.Collections.Generic.List[string]
    $instanceOcids = [regex]::Matches($Text, "ocid1\.instance\.[A-Za-z0-9._-]+", [System.Text.RegularExpressions.RegexOptions]::IgnoreCase) |
        ForEach-Object { $_.Value } |
        Sort-Object -Unique

    foreach ($instanceOcid in $instanceOcids) {
        $reason = ""
        if ($InstanceReasonOverrides.ContainsKey($instanceOcid)) {
            $reason = $InstanceReasonOverrides[$instanceOcid]
        }
        elseif ($instanceOcid -match "ocid1\.instance\.oc1\.eu-frankfurt-1\.") {
            $reason = "Out of capacity error"
        }
        elseif ($instanceOcid -match "ocid1\.instance\.oc1\.iad\.") {
            $reason = "Bad HV"
        }

        if (-not [string]::IsNullOrWhiteSpace($reason) -and -not ($reasons -contains $reason)) {
            $reasons.Add($reason) | Out-Null
        }
    }

    if ($reasons.Count -gt 0) {
        return ($reasons.ToArray() -join "; ")
    }

    return ""
}

function Get-SheetRows {
    param(
        [xml]$SheetXml,
        [string[]]$SharedStrings
    )

    $rows = New-Object System.Collections.Generic.List[object]
    $sheetNode = [System.Xml.XmlNode]$SheetXml
    foreach ($rowNode in $sheetNode.SelectNodes("//*[local-name()='sheetData']/*[local-name()='row']")) {
        $rowXmlNode = [System.Xml.XmlNode]$rowNode
        $cellsByColumn = @{}
        foreach ($cell in $rowXmlNode.SelectNodes("./*[local-name()='c']")) {
            $reference = [string]$cell.r
            $column = Get-ColumnNameFromReference -Reference $reference
            $cellsByColumn[$column] = Get-CellValue -Cell $cell -SharedStrings $SharedStrings
        }

        $rows.Add([PSCustomObject]@{
                Node = $rowXmlNode
                RowNumber = [int]$rowXmlNode.r
                Cells = $cellsByColumn
            }) | Out-Null
    }

    return $rows
}

function New-InlineCellNode {
    param(
        [xml]$SheetXml,
        [string]$Reference,
        [string]$Value
    )

    $cellNode = $SheetXml.CreateElement("c", $SpreadsheetNamespace)
    $null = $cellNode.SetAttribute("r", $Reference)
    $null = $cellNode.SetAttribute("t", "inlineStr")

    $isNode = $SheetXml.CreateElement("is", $SpreadsheetNamespace)
    $textNode = $SheetXml.CreateElement("t", $SpreadsheetNamespace)
    $spaceAttribute = $SheetXml.CreateAttribute("xml", "space", $XmlNamespace)
    $spaceAttribute.Value = "preserve"
    $textNode.Attributes.Append($spaceAttribute) | Out-Null
    $textNode.InnerText = [string]$Value

    $isNode.AppendChild($textNode) | Out-Null
    $cellNode.AppendChild($isNode) | Out-Null

    return $cellNode
}

function Set-RowCells {
    param(
        [xml]$SheetXml,
        [System.Xml.XmlNode]$RowNode,
        [int]$RowNumber,
        [hashtable]$ValuesByColumn,
        [string[]]$OrderedColumns,
        [string]$Spans
    )

    $rowXmlNode = [System.Xml.XmlNode]$RowNode
    foreach ($cell in @($rowXmlNode.SelectNodes("./*[local-name()='c']"))) {
        $null = $rowXmlNode.RemoveChild($cell)
    }

    $null = $rowXmlNode.SetAttribute("r", [string]$RowNumber)
    if (-not [string]::IsNullOrWhiteSpace($Spans)) {
        $null = $rowXmlNode.SetAttribute("spans", $Spans)
    }

    foreach ($column in $OrderedColumns) {
        $cellNode = New-InlineCellNode -SheetXml $SheetXml -Reference "$column$RowNumber" -Value ([string]$ValuesByColumn[$column])
        $rowXmlNode.AppendChild($cellNode) | Out-Null
    }
}

function Get-CellTextOrBlank {
    param(
        [hashtable]$Cells,
        [string]$Column
    )

    if ($Cells.ContainsKey($Column)) {
        return [string]$Cells[$Column]
    }

    return ""
}

function Get-RowValuesByColumns {
    param(
        [hashtable]$Cells,
        [string[]]$OrderedColumns
    )

    $values = @{}
    foreach ($column in $OrderedColumns) {
        $values[$column] = Get-CellTextOrBlank -Cells $Cells -Column $column
    }

    return $values
}

function Ensure-Dimension {
    param(
        [xml]$SheetXml,
        [string]$LastColumn,
        [int]$LastRow
    )

    $sheetNode = [System.Xml.XmlNode]$SheetXml
    $dimensionNode = $sheetNode.SelectSingleNode("//*[local-name()='dimension']")
    if ($null -eq $dimensionNode) {
        return
    }

    $null = $dimensionNode.SetAttribute("ref", "A1:$LastColumn$LastRow")
}

function Ensure-ColumnWidth {
    param(
        [xml]$SheetXml,
        [string]$ColumnName,
        [double]$Width
    )

    $sheetNode = [System.Xml.XmlNode]$SheetXml
    $columnIndex = Convert-ColumnNameToIndex -ColumnName $ColumnName

    $colsNode = $sheetNode.SelectSingleNode("//*[local-name()='cols']")
    if ($null -eq $colsNode) {
        $colsNode = $SheetXml.CreateElement("cols", $SpreadsheetNamespace)
        $sheetFormatPr = $sheetNode.SelectSingleNode("//*[local-name()='sheetFormatPr']")
        if ($null -ne $sheetFormatPr) {
            $sheetFormatPr.ParentNode.InsertAfter($colsNode, $sheetFormatPr) | Out-Null
        }
        else {
            $sheetData = $sheetNode.SelectSingleNode("//*[local-name()='sheetData']")
            $sheetData.ParentNode.InsertBefore($colsNode, $sheetData) | Out-Null
        }
    }

    $targetColumnNode = $null
    foreach ($columnNode in $colsNode.SelectNodes("./*[local-name()='col']")) {
        $min = [int]$columnNode.GetAttribute("min")
        $max = [int]$columnNode.GetAttribute("max")
        if ($min -eq $columnIndex -and $max -eq $columnIndex) {
            $targetColumnNode = $columnNode
            break
        }
    }

    if ($null -eq $targetColumnNode) {
        $targetColumnNode = $SheetXml.CreateElement("col", $SpreadsheetNamespace)
        $null = $targetColumnNode.SetAttribute("min", [string]$columnIndex)
        $null = $targetColumnNode.SetAttribute("max", [string]$columnIndex)
        $colsNode.AppendChild($targetColumnNode) | Out-Null
    }

    $null = $targetColumnNode.SetAttribute("width", [string]$Width)
    $null = $targetColumnNode.SetAttribute("customWidth", "1")
}

function Convert-XmlDocumentToText {
    param([xml]$XmlDocument)

    return "<?xml version=`"1.0`" encoding=`"UTF-8`" standalone=`"yes`"?>`r`n$($XmlDocument.DocumentElement.OuterXml)"
}

function Copy-EntryBytes {
    param(
        [System.IO.Compression.ZipArchiveEntry]$SourceEntry,
        [System.IO.Compression.ZipArchive]$DestinationArchive
    )

    $destinationEntry = $DestinationArchive.CreateEntry($SourceEntry.FullName)
    $sourceStream = $SourceEntry.Open()
    $destinationStream = $destinationEntry.Open()

    try {
        $sourceStream.CopyTo($destinationStream)
    }
    finally {
        $destinationStream.Dispose()
        $sourceStream.Dispose()
    }
}

function Write-StringEntry {
    param(
        [System.IO.Compression.ZipArchive]$DestinationArchive,
        [string]$EntryName,
        [string]$Content
    )

    $entry = $DestinationArchive.CreateEntry($EntryName)
    $stream = $entry.Open()
    $writer = New-Object System.IO.StreamWriter($stream, [System.Text.UTF8Encoding]::new($false))
    try {
        $writer.Write($Content)
    }
    finally {
        $writer.Dispose()
    }
}

if (-not (Test-Path -LiteralPath $WorkbookPath)) {
    throw "Workbook '$WorkbookPath' was not found."
}

$backupTimestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$directory = Split-Path -Parent $WorkbookPath
$filename = [System.IO.Path]::GetFileNameWithoutExtension($WorkbookPath)
$extension = [System.IO.Path]::GetExtension($WorkbookPath)
$backupPath = Join-Path $directory "$filename.backup_$backupTimestamp$extension"
Copy-Item -LiteralPath $WorkbookPath -Destination $backupPath -Force

$sourceArchive = [System.IO.Compression.ZipFile]::OpenRead($WorkbookPath)
try {
    $sharedStrings = Get-SharedStrings -Archive $sourceArchive

    $ocidSheetEntry = Get-WorksheetEntryName -Archive $sourceArchive -PreferredSheetName "SR OCIDs"
    $summarySheetEntry = Get-WorksheetEntryName -Archive $sourceArchive -PreferredSheetName $SummarySheetName

    [xml]$ocidSheetXml = Read-ZipEntryText -Archive $sourceArchive -EntryName $ocidSheetEntry
    [xml]$summarySheetXml = Read-ZipEntryText -Archive $sourceArchive -EntryName $summarySheetEntry

    $ocidRows = Get-SheetRows -SheetXml $ocidSheetXml -SharedStrings $sharedStrings
    $summaryRows = Get-SheetRows -SheetXml $summarySheetXml -SharedStrings $sharedStrings

    $ocidHeaderRow = $ocidRows | Select-Object -First 1
    $summaryHeaderRow = $summaryRows | Select-Object -First 1

    $ocidHeaderMap = Get-HeaderMap -HeaderCells $ocidHeaderRow.Cells
    $summaryHeaderMap = Get-HeaderMap -HeaderCells $summaryHeaderRow.Cells

    $ocidSrColumn = Get-HeaderColumnOrDefault -HeaderMap $ocidHeaderMap -HeaderName "SR" -DefaultColumn "A"
    $ocidInstanceColumn = Get-HeaderColumnOrDefault -HeaderMap $ocidHeaderMap -HeaderName "InstanceOCID" -DefaultColumn "C"

    $summarySrColumn = Get-HeaderColumnOrDefault -HeaderMap $summaryHeaderMap -HeaderName "SR" -DefaultColumn "A"
    $summaryOcidsColumn = Get-HeaderColumnOrDefault -HeaderMap $summaryHeaderMap -HeaderName "OCID(s)" -DefaultColumn "I"

    $ocidColumns = Get-OrderedColumnsFromHeaderRow -HeaderCells $ocidHeaderRow.Cells
    if (-not $ocidHeaderMap.ContainsKey($ReasonHeaderName)) {
        $ocidColumns += Convert-ColumnIndexToName -ColumnIndex ((Convert-ColumnNameToIndex -ColumnName $ocidColumns[-1]) + 1)
    }
    $ocidReasonColumn = if ($ocidHeaderMap.ContainsKey($ReasonHeaderName)) { [string]$ocidHeaderMap[$ReasonHeaderName] } else { $ocidColumns[-1] }
    $ocidSpan = Get-SpanStringFromColumns -OrderedColumns $ocidColumns

    $summaryColumns = Get-OrderedColumnsFromHeaderRow -HeaderCells $summaryHeaderRow.Cells
    if (-not $summaryHeaderMap.ContainsKey($ReasonHeaderName)) {
        $summaryColumns += Convert-ColumnIndexToName -ColumnIndex ((Convert-ColumnNameToIndex -ColumnName $summaryColumns[-1]) + 1)
    }
    $summaryReasonColumn = if ($summaryHeaderMap.ContainsKey($ReasonHeaderName)) { [string]$summaryHeaderMap[$ReasonHeaderName] } else { $summaryColumns[-1] }
    $summarySpan = Get-SpanStringFromColumns -OrderedColumns $summaryColumns

    $ocidsBySr = @{}
    foreach ($row in $ocidRows | Select-Object -Skip 1) {
        $sr = Get-CellTextOrBlank -Cells $row.Cells -Column $ocidSrColumn
        $instanceOcid = Get-CellTextOrBlank -Cells $row.Cells -Column $ocidInstanceColumn
        if ([string]::IsNullOrWhiteSpace($sr) -or [string]::IsNullOrWhiteSpace($instanceOcid)) {
            continue
        }

        if (-not $ocidsBySr.ContainsKey($sr)) {
            $ocidsBySr[$sr] = New-Object System.Collections.Generic.List[string]
        }

        if (-not ($ocidsBySr[$sr] -contains $instanceOcid)) {
            $ocidsBySr[$sr].Add($instanceOcid) | Out-Null
        }
    }

    foreach ($row in $ocidRows) {
        $rowValues = Get-RowValuesByColumns -Cells $row.Cells -OrderedColumns $ocidColumns
        if ($row.RowNumber -eq 1) {
            $rowValues[$ocidReasonColumn] = $ReasonHeaderName
        }
        else {
            $rowValues[$ocidReasonColumn] = Get-StuckReasonFromText -Text (Get-CellTextOrBlank -Cells $row.Cells -Column $ocidInstanceColumn)
        }

        Set-RowCells -SheetXml $ocidSheetXml -RowNode $row.Node -RowNumber $row.RowNumber -ValuesByColumn $rowValues -OrderedColumns $ocidColumns -Spans $ocidSpan
    }

    foreach ($row in $summaryRows) {
        $rowValues = Get-RowValuesByColumns -Cells $row.Cells -OrderedColumns $summaryColumns
        if ($row.RowNumber -eq 1) {
            $rowValues[$summaryReasonColumn] = $ReasonHeaderName
        }
        else {
            $summaryOcidText = Get-CellTextOrBlank -Cells $row.Cells -Column $summaryOcidsColumn
            if ([string]::IsNullOrWhiteSpace($summaryOcidText)) {
                $sr = Get-CellTextOrBlank -Cells $row.Cells -Column $summarySrColumn
                if ($ocidsBySr.ContainsKey($sr)) {
                    $summaryOcidText = ($ocidsBySr[$sr].ToArray() -join "; ")
                }
            }

            $rowValues[$summaryReasonColumn] = Get-StuckReasonFromText -Text $summaryOcidText
        }

        Set-RowCells -SheetXml $summarySheetXml -RowNode $row.Node -RowNumber $row.RowNumber -ValuesByColumn $rowValues -OrderedColumns $summaryColumns -Spans $summarySpan
    }

    Ensure-Dimension -SheetXml $ocidSheetXml -LastColumn $ocidColumns[-1] -LastRow ($ocidRows | Select-Object -Last 1).RowNumber
    Ensure-Dimension -SheetXml $summarySheetXml -LastColumn $summaryColumns[-1] -LastRow ($summaryRows | Select-Object -Last 1).RowNumber

    Ensure-ColumnWidth -SheetXml $ocidSheetXml -ColumnName $ocidReasonColumn -Width 28
    Ensure-ColumnWidth -SheetXml $summarySheetXml -ColumnName $summaryReasonColumn -Width 28

    $replacementEntries = @{
        $ocidSheetEntry = Convert-XmlDocumentToText -XmlDocument $ocidSheetXml
        $summarySheetEntry = Convert-XmlDocumentToText -XmlDocument $summarySheetXml
    }

    $tempPath = Join-Path $directory "$filename.reason_update_$backupTimestamp$extension"
    $destinationStream = [System.IO.File]::Open($tempPath, [System.IO.FileMode]::Create)
    try {
        $destinationArchive = New-Object System.IO.Compression.ZipArchive($destinationStream, [System.IO.Compression.ZipArchiveMode]::Create, $false)
        try {
            foreach ($entry in $sourceArchive.Entries) {
                if ($replacementEntries.ContainsKey($entry.FullName)) {
                    Write-StringEntry -DestinationArchive $destinationArchive -EntryName $entry.FullName -Content $replacementEntries[$entry.FullName]
                }
                else {
                    Copy-EntryBytes -SourceEntry $entry -DestinationArchive $destinationArchive
                }
            }
        }
        finally {
            $destinationArchive.Dispose()
        }
    }
    finally {
        $destinationStream.Dispose()
    }
}
finally {
    $sourceArchive.Dispose()
}

Move-Item -LiteralPath $tempPath -Destination $WorkbookPath -Force

[PSCustomObject]@{
    WorkbookPath = (Resolve-Path -LiteralPath $WorkbookPath).Path
    BackupPath = (Resolve-Path -LiteralPath $backupPath).Path
    OcidReasonColumn = $ocidReasonColumn
    SummaryReasonColumn = $summaryReasonColumn
    OcidRowCount = ($ocidRows.Count - 1)
    SummaryRowCount = ($summaryRows.Count - 1)
} | ConvertTo-Json -Depth 4
