import argparse
from pathlib import Path

from openpyxl import load_workbook


def add_unique(values, target, seen):
    for value in values:
        text = "" if value is None else str(value).strip()
        if text and text not in seen:
            target.append(text)
            seen.add(text)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--workbook", required=True)
    parser.add_argument("--requested", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    ordered = []
    seen = set()

    wb = load_workbook(args.workbook, read_only=True, data_only=True)
    ws = wb.active
    rows = ws.iter_rows(values_only=True)
    headers = ["" if value is None else str(value).strip() for value in next(rows)]
    sr_index = headers.index("SR Number") if "SR Number" in headers else 0
    add_unique((row[sr_index] for row in rows if len(row) > sr_index), ordered, seen)
    wb.close()

    requested_values = Path(args.requested).read_text(encoding="utf-8").splitlines()
    add_unique(requested_values, ordered, seen)

    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text("\n".join(ordered) + "\n", encoding="utf-8")
    print({"count": len(ordered), "output": str(output.resolve())})


if __name__ == "__main__":
    main()
