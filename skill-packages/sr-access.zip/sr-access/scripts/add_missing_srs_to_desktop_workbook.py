import argparse
import copy
import json
from pathlib import Path

from openpyxl import load_workbook


def load_requested(path):
    seen = set()
    values = []
    for raw_line in Path(path).read_text(encoding="utf-8").splitlines():
        value = raw_line.strip()
        if value and value not in seen:
            values.append(value)
            seen.add(value)
    return values


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--details", required=True)
    parser.add_argument("--requested", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    wb = load_workbook(args.input)
    ws = wb.active

    headers = [cell.value or "" for cell in ws[1]]
    header_to_col = {str(value).strip(): index + 1 for index, value in enumerate(headers) if str(value).strip()}
    sr_col = header_to_col.get("SR Number") or header_to_col.get("SR") or 1

    existing = set()
    for row in range(2, ws.max_row + 1):
        value = ws.cell(row=row, column=sr_col).value
        if value:
            existing.add(str(value).strip())

    requested = load_requested(args.requested)
    details = json.loads(Path(args.details).read_text(encoding="utf-8"))
    detail_by_sr = {str(row["SR"]): row for row in details.get("rows", [])}
    error_by_sr = {str(row["SR"]): row.get("error", "") for row in details.get("errors", [])}

    missing = [sr for sr in requested if sr not in existing]
    template_row = ws.max_row

    for sr in missing:
        row_index = ws.max_row + 1
        for col in range(1, ws.max_column + 1):
            source = ws.cell(row=template_row, column=col)
            target = ws.cell(row=row_index, column=col)
            if source.has_style:
                target._style = copy.copy(source._style)
            if source.number_format:
                target.number_format = source.number_format
            if source.alignment:
                target.alignment = copy.copy(source.alignment)
            if source.font:
                target.font = copy.copy(source.font)
            if source.fill:
                target.fill = copy.copy(source.fill)
            if source.border:
                target.border = copy.copy(source.border)

        detail = detail_by_sr.get(sr, {})
        values = {
            "SR Number": sr,
            "SR": sr,
            "Status": detail.get("Status", ""),
            "Severity": detail.get("Severity", ""),
            "Summary": detail.get("SRHeading", "") or (
                f"Fetch failed: {error_by_sr[sr]}" if sr in error_by_sr else ""
            ),
            "Primary Contact": detail.get("CreatedBy", ""),
        }
        for header, value in values.items():
            column = header_to_col.get(header)
            if column:
                ws.cell(row=row_index, column=column).value = value

    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    wb.save(args.output)
    print(json.dumps({"missingAdded": len(missing), "missing": missing, "output": str(Path(args.output).resolve())}))


if __name__ == "__main__":
    main()
