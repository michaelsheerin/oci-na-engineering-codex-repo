import argparse
import json
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path


def load_dotenv(path):
    values = {}
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        values[key.strip()] = value
    return values


def compact_text(value):
    if value is None:
        return ""
    text = str(value)
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def pick_description(sr):
    for key in ("ProblemDescription", "SRDescription_c", "ResolveDescription", "TransferNote"):
        text = compact_text(sr.get(key))
        if text:
            return text
    return ""


def write_progress(output_path, requested, rows, errors):
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(
        json.dumps({"requested": requested, "rows": rows, "errors": errors}, indent=2),
        encoding="utf-8",
    )


def get_json(url, auth_header):
    request = urllib.request.Request(
        url,
        headers={
            "Authorization": auth_header,
            "Accept": "application/json",
            "User-Agent": "Codex-SR-Workbook-Updater/1.0",
        },
    )
    with urllib.request.urlopen(request, timeout=25) as response:
        return json.loads(response.read().decode("utf-8"))


def fetch_sr(base_url, resource_paths, sr_number, auth_header):
    last_error = None
    for resource_path in resource_paths:
        direct_url = f"{base_url}{resource_path}/{urllib.parse.quote(sr_number, safe='')}"
        try:
            return get_json(direct_url, auth_header)
        except urllib.error.HTTPError as exc:
            last_error = exc
            if exc.code not in (400, 404):
                raise

        query = urllib.parse.urlencode({"q": f"SrNumber='{sr_number}'", "limit": "1"})
        search_url = f"{base_url}{resource_path}?{query}"
        try:
            payload = get_json(search_url, auth_header)
            items = payload.get("items") or []
            if items:
                return items[0]
        except urllib.error.HTTPError as exc:
            last_error = exc
            if exc.code not in (400, 404):
                raise

    if last_error is not None:
        raise last_error
    raise RuntimeError(f"SR not found: {sr_number}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--env", required=True)
    parser.add_argument("--sr-list", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--sleep", type=float, default=0.05)
    parser.add_argument("--limit", type=int, default=0)
    args = parser.parse_args()

    env = load_dotenv(Path(args.env))
    auth_header = env.get("SR_AUTH_HEADER") or (
        f"Bearer {env['SR_BEARER_TOKEN']}" if env.get("SR_BEARER_TOKEN") else ""
    )
    if not auth_header:
        raise RuntimeError("SR_AUTH_HEADER or SR_BEARER_TOKEN is required")

    base_url = env.get("SR_BASE_URL", "").rstrip("/")
    configured_resource_path = env.get("SR_RESOURCE_PATH", "/crmRestApi/resources/latest/serviceRequests")
    resource_paths = []
    for candidate in (
        configured_resource_path,
        "/crmRestApi/resources/latest/serviceRequests",
        "/crmRestApi/resources/11.13.18.05/serviceRequests",
        "/fscmRestApi/resources/latest/serviceRequests",
    ):
        if candidate and candidate not in resource_paths:
            resource_paths.append(candidate)
    if not base_url:
        raise RuntimeError("SR_BASE_URL is required")

    sr_numbers = []
    seen = set()
    for raw_line in Path(args.sr_list).read_text(encoding="utf-8").splitlines():
        sr_number = raw_line.strip()
        if sr_number and sr_number not in seen:
            sr_numbers.append(sr_number)
            seen.add(sr_number)

    output_path = Path(args.output)
    rows = []
    errors = []
    completed = set()
    if output_path.exists():
        previous = json.loads(output_path.read_text(encoding="utf-8"))
        rows = previous.get("rows") or []
        errors = previous.get("errors") or []
        completed = {row.get("SR") for row in rows}
        errors = []

    pending = [sr for sr in sr_numbers if sr not in completed]
    if args.limit and args.limit > 0:
        pending = pending[: args.limit]

    for index, sr_number in enumerate(pending, 1):
        try:
            sr = fetch_sr(base_url, resource_paths, sr_number, auth_header)
            rows.append(
                {
                    "SR": sr_number,
                    "SRHeading": compact_text(sr.get("Title")),
                    "CreationDate": compact_text(sr.get("CreationDate")),
                    "LastUpdateDate": compact_text(sr.get("LastUpdateDate")),
                    "IssueDescription": pick_description(sr),
                    "Severity": compact_text(sr.get("SeverityCdMeaning")),
                    "Status": compact_text(sr.get("StatusCdMeaning")),
                    "CreatedBy": compact_text(sr.get("CreatedBy")),
                    "SROwner": compact_text(sr.get("AssigneePersonName")),
                }
            )
        except Exception as exc:
            errors.append({"SR": sr_number, "error": str(exc)})
        write_progress(output_path, sr_numbers, rows, errors)
        print(f"{index}/{len(pending)} {sr_number}", file=sys.stderr, flush=True)
        if args.sleep:
            time.sleep(args.sleep)

    write_progress(output_path, sr_numbers, rows, errors)
    print(json.dumps({"requested": len(sr_numbers), "fetched": len(rows), "errors": len(errors)}))


if __name__ == "__main__":
    main()
