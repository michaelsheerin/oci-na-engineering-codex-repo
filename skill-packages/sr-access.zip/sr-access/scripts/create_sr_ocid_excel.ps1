param(
    [string]$OutputPath = (Join-Path (Get-Location) "sr_ocids_date_only.xlsx"),
    [string]$InputCsvPath = ""
)

$ErrorActionPreference = "Stop"

Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

$rawCsv = if (-not [string]::IsNullOrWhiteSpace($InputCsvPath)) {
    Get-Content -LiteralPath $InputCsvPath -Raw
}
else {
@'
SR,SRCreatedUTC,InstanceOCID
SR-123456,2026-01-01 00:00:00 UTC,example-instance-ocid
'@
}

$rows = $rawCsv | ConvertFrom-Csv | ForEach-Object {
    [PSCustomObject]@{
        SR = $_.SR
        SRCreatedDate = ($_.SRCreatedUTC -replace " .*", "")
        InstanceOCID = $_.InstanceOCID
    }
}

function New-InlineCellXml {
    param(
        [string]$Reference,
        [string]$Value
    )

    $escapedValue = [System.Security.SecurityElement]::Escape($Value)
    if ($null -eq $escapedValue) {
        $escapedValue = ""
    }

    return "<c r=`"$Reference`" t=`"inlineStr`"><is><t>$escapedValue</t></is></c>"
}

function New-RowXml {
    param(
        [int]$RowNumber,
        [string[]]$Values
    )

    $columns = @("A", "B", "C")
    $cells = for ($i = 0; $i -lt $Values.Count; $i++) {
        New-InlineCellXml -Reference ($columns[$i] + $RowNumber) -Value $Values[$i]
    }

    return "<row r=`"$RowNumber`">$($cells -join '')</row>"
}

function Add-ZipEntry {
    param(
        [System.IO.Compression.ZipArchive]$Archive,
        [string]$EntryName,
        [string]$Content
    )

    $entry = $Archive.CreateEntry($EntryName)
    $stream = $entry.Open()
    $writer = New-Object System.IO.StreamWriter($stream, [System.Text.UTF8Encoding]::new($false))
    $writer.Write($Content)
    $writer.Dispose()
}

$rowXml = New-Object System.Collections.Generic.List[string]
$rowXml.Add((New-RowXml -RowNumber 1 -Values @("SR", "SRCreatedDate", "InstanceOCID")))

$excelRowNumber = 2
foreach ($row in $rows) {
    $rowXml.Add((New-RowXml -RowNumber $excelRowNumber -Values @(
        [string]$row.SR,
        [string]$row.SRCreatedDate,
        [string]$row.InstanceOCID
    )))
    $excelRowNumber++
}

$lastRow = $rows.Count + 1

$contentTypesXml = @"
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
  <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
</Types>
"@

$rootRelsXml = @"
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>
"@

$workbookXml = @"
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheets>
    <sheet name="SR OCIDs" sheetId="1" r:id="rId1"/>
  </sheets>
</workbook>
"@

$workbookRelsXml = @"
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
</Relationships>
"@

$worksheetXml = @"
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <dimension ref="A1:C$lastRow"/>
  <sheetData>
    $($rowXml -join "`n    ")
  </sheetData>
</worksheet>
"@

$outputDirectory = Split-Path -Parent $OutputPath
if (-not [string]::IsNullOrWhiteSpace($outputDirectory) -and -not (Test-Path $outputDirectory)) {
    New-Item -ItemType Directory -Path $outputDirectory | Out-Null
}

$fileStream = [System.IO.File]::Open($OutputPath, [System.IO.FileMode]::Create)
try {
    $archive = New-Object System.IO.Compression.ZipArchive($fileStream, [System.IO.Compression.ZipArchiveMode]::Create, $false)
    try {
        Add-ZipEntry -Archive $archive -EntryName "[Content_Types].xml" -Content $contentTypesXml
        Add-ZipEntry -Archive $archive -EntryName "_rels/.rels" -Content $rootRelsXml
        Add-ZipEntry -Archive $archive -EntryName "xl/workbook.xml" -Content $workbookXml
        Add-ZipEntry -Archive $archive -EntryName "xl/_rels/workbook.xml.rels" -Content $workbookRelsXml
        Add-ZipEntry -Archive $archive -EntryName "xl/worksheets/sheet1.xml" -Content $worksheetXml
    }
    finally {
        $archive.Dispose()
    }
}
finally {
    $fileStream.Dispose()
}

Write-Output $OutputPath
