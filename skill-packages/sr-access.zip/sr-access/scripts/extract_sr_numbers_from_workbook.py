import argparse
import re
from pathlib import Path

from openpyxl import load_workbook


SR_PATTERN = re.compile(r"\b4-\d{10}\b")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--workbook", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    wb = load_workbook(args.workbook, read_only=True, data_only=True)
    ordered = []
    seen = set()

    for ws in wb.worksheets:
        rows = ws.iter_rows(values_only=True)
        try:
            headers = ["" if value is None else str(value).strip() for value in next(rows)]
        except StopIteration:
            continue
        candidate_indexes = [
            index
            for index, header in enumerate(headers)
            if "sr" in header.lower() or "task" in header.lower() or "note" in header.lower()
        ]
        if not candidate_indexes:
            candidate_indexes = range(len(headers))

        for row in rows:
            for index in candidate_indexes:
                if index >= len(row):
                    continue
                for sr in SR_PATTERN.findall(str(row[index] or "")):
                    if sr not in seen:
                        ordered.append(sr)
                        seen.add(sr)

    wb.close()
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text("\n".join(ordered) + "\n", encoding="utf-8")
    print({"count": len(ordered), "output": str(output.resolve())})


if __name__ == "__main__":
    main()
