# How to Use the SR Analysis Skill

This workspace contains the `sr-access` skill for Oracle Service Request (SR) access and SR data handling. Use it when you need to fetch SR details, analyze SR records, or update local SR reports from this workspace.

## What the Skill Does

The skill uses local scripts to call Oracle Fusion Service REST APIs and save SR details into local files for analysis.

Main script:

```powershell
python scripts/fetch_sr_details.py --env .env --sr-list inputs/sr_numbers.txt --output outputs/sr_details.json
```

The script reads SR numbers from a text file, fetches details from Oracle, and writes JSON rows for reporting or workbook updates.

## One-Time Setup

Copy `.env.example` to `.env`, then add your own token:

```dotenv
SR_BEARER_TOKEN=<token>
```

You can also use the full authorization header instead:

```dotenv
SR_AUTH_HEADER=Bearer <token>
```

The default Oracle base URL and resource path are already shown in `.env.example`.

Requirements:

- VPN access, if Oracle requires it.
- A valid bearer token.
- API entitlement for the service request REST resource.
- Keep `.env` local. Do not share or commit real tokens.

## Fetch SR Details

Copy `inputs/sr_numbers.example.txt` to a new file such as `inputs/my_srs.txt`, then add one SR number per line. Live input files are ignored so they are not included in a shared package:

```text
SR-123456
SR-234567
SR-345678
```

Run the fetcher:

```powershell
python scripts/fetch_sr_details.py --env .env --sr-list inputs/sr_numbers.txt --output outputs/sr_details.json
```

Useful optional flags:

```powershell
python scripts/fetch_sr_details.py --env .env --sr-list inputs/sr_numbers.txt --output outputs/sr_details.json --limit 10 --sleep 0.1
```

- `--limit` fetches only the first N SRs, useful for testing.
- `--sleep` adds a delay between requests.

## Output Fields

The JSON output includes these fields when Oracle returns them:

- `SR`
- `SRHeading`
- `CreationDate`
- `LastUpdateDate`
- `IssueDescription`
- `Severity`
- `Status`
- `CreatedBy`
- `SROwner`

Use this JSON as the source for summaries, metrics, workbook updates, or manual review.

## Other Helpful Scripts

- `scripts/analyze_sr_metrics.py` analyzes fetched SR detail JSON.
- `scripts/write_sr_workbook.ps1` creates an Excel workbook from SR detail JSON.
- `scripts/update_requested_sr_workbook.ps1` updates a requested SR workbook using SR numbers and `.env`.
- `scripts/extract_sr_numbers_from_workbook.py` extracts SR numbers from an existing workbook.
- `scripts/extract_union_srs.py` combines SR lists.

## Good Prompt Examples

Ask Codex things like:

```text
Use the SR analysis skill to fetch the SRs listed in inputs/my_srs.txt and save the result to outputs/my_srs_details.json.
```

```text
Analyze outputs/sr_details.json and summarize the top issue themes, severities, owners, and stale SRs.
```

```text
Update the workbook from these SRs and tell me which SRs could not be fetched.
```

## Sharing Hygiene

Keep these local unless explicitly sanitized:

- `.env`
- Output JSON files
- Generated workbooks
- Cache files
- Real OCIDs
- Bearer tokens
- Copied browser authorization headers

Before sharing a package, remove secrets and private customer data.
