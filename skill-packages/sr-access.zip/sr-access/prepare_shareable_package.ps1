param(
    [string]$SourceRoot = $PSScriptRoot,
    [string]$PackageName = "sr-access-shareable"
)

$ErrorActionPreference = "Stop"

$SourceRoot = [System.IO.Path]::GetFullPath($SourceRoot)
$Parent = Split-Path -Parent $SourceRoot
$Timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$StageRoot = Join-Path $Parent "$PackageName-$Timestamp"
$ZipPath = Join-Path $Parent "$PackageName-$Timestamp.zip"

$excludedNames = @(
    ".env",
    "__pycache__"
)

$excludedPatterns = @(
    "*.xlsx",
    "*.xls",
    "*.xlsm",
    "*.pyc",
    "~$*"
)

function Test-IsExcluded {
    param([System.IO.FileSystemInfo]$Item)

    if ($excludedNames -contains $Item.Name) {
        return $true
    }

    # Only the checked-in template may be shared.  All live SR lists stay local.
    if ($Item.Extension -eq ".txt" -and $Item.Name -notlike "*.example.txt") {
        return $true
    }

    foreach ($pattern in $excludedPatterns) {
        if ($Item.Name -like $pattern) {
            return $true
        }
    }

    return $false
}

function Copy-SafeTree {
    param(
        [string]$Source,
        [string]$Destination
    )

    New-Item -ItemType Directory -Path $Destination -Force | Out-Null

    foreach ($item in Get-ChildItem -LiteralPath $Source -Force) {
        if (Test-IsExcluded -Item $item) {
            continue
        }

        $target = Join-Path $Destination $item.Name
        if ($item.PSIsContainer) {
            Copy-SafeTree -Source $item.FullName -Destination $target
        }
        else {
            Copy-Item -LiteralPath $item.FullName -Destination $target
        }
    }
}

function Write-Utf8NoBom {
    param(
        [string]$Path,
        [string]$Content
    )

    [System.IO.File]::WriteAllText($Path, $Content, [System.Text.UTF8Encoding]::new($false))
}

function Update-FileText {
    param(
        [string]$RelativePath,
        [scriptblock]$Transform
    )

    $path = Join-Path $StageRoot $RelativePath
    if (-not (Test-Path -LiteralPath $path)) {
        return
    }

    $content = Get-Content -LiteralPath $path -Raw
    $updated = & $Transform $content
    Write-Utf8NoBom -Path $path -Content $updated
}

Copy-SafeTree -Source $SourceRoot -Destination $StageRoot

$envExample = @'
# Copy this file to .env and fill in your own bearer token.
SR_BEARER_TOKEN=

# Or use the full Authorization header instead:
# SR_AUTH_HEADER=Bearer <token>

SR_BASE_URL=https://fa-etmi-saasfaprod1.fa.ocs.oraclecloud.com
SR_RESOURCE_PATH=/fscmRestApi/resources/11.13.18.05/serviceRequests
'@
Write-Utf8NoBom -Path (Join-Path $StageRoot ".env.example") -Content $envExample

$gitignore = @'
.env
outputs/
*.xlsx
*.xls
*.xlsm
*.backup_*.xlsx
__pycache__/
*.pyc
~$*
inputs/*.txt
!inputs/*.example.txt
'@
Write-Utf8NoBom -Path (Join-Path $StageRoot ".gitignore") -Content $gitignore

Update-FileText -RelativePath "scripts\create_sr_ocid_excel.ps1" -Transform {
    param($content)

    $content = [regex]::Replace(
        $content,
        "param\(\s*\[string\]\`$OutputPath = \(Join-Path \(Get-Location\) `"sr_ocids_date_only\.xlsx`"\)\s*\)",
        "param(`r`n    [string]`$OutputPath = (Join-Path (Get-Location) `"sr_ocids_date_only.xlsx`"),`r`n    [string]`$InputCsvPath = `"`"`r`n)"
    )

    $safeRawCsvBlock = @(
        '$rawCsv = if (-not [string]::IsNullOrWhiteSpace($InputCsvPath)) {'
        '    Get-Content -LiteralPath $InputCsvPath -Raw'
        '}'
        'else {'
        "@'"
        'SR,SRCreatedUTC,InstanceOCID'
        'SR-123456,2026-01-01 00:00:00 UTC,example-instance-ocid'
        "'@"
        '}'
    ) -join "`r`n"

    [regex]::Replace($content, "(?s)\`$rawCsv = @'.*?'@", $safeRawCsvBlock)
}

$overrideReplacement = @'
$InstanceReasonOverrides = @{
    # Add team-specific one-off OCID reason overrides here if needed.
    # Example: "example-instance-ocid" = "Unhealthy HV"
}
'@

foreach ($relativePath in @(
        "scripts\add_manual_sr_ocid_entry.ps1",
        "scripts\add_stuck_reason_column.ps1",
        "scripts\update_requested_sr_workbook.ps1"
    )) {
    Update-FileText -RelativePath $relativePath -Transform {
        param($content)
        [regex]::Replace($content, "(?s)\`$InstanceReasonOverrides = @\{.*?\}", $overrideReplacement)
    }
}

Update-FileText -RelativePath "SKILL.md" -Transform {
    param($content)

    $sharingBlock = @'

## Sharing Hygiene

- Each teammate must copy `.env.example` to `.env` and add their own `SR_BEARER_TOKEN`.
- Keep `.env`, generated workbooks, output JSON, and cache files local.
- Do not commit or share real OCIDs, bearer tokens, private keys, or copied browser authorization headers.
- If a script needs one-off OCID reason overrides, add them locally before running and remove them before sharing.
'@

    if ($content -notmatch "## Sharing Hygiene") {
        $content = $content.TrimEnd() + $sharingBlock + "`r`n"
    }

    $content
}

$findings = Get-ChildItem -LiteralPath $StageRoot -Recurse -File -Force |
    Where-Object { $_.Name -ne "prepare_shareable_package.ps1" } |
    Select-String -Pattern "ocid1\.|Bearer [A-Za-z0-9._~+/-]{8,}|SR_AUTH_HEADER=Bearer [^<]|BEGIN (RSA |OPENSSH |PRIVATE )?PRIVATE KEY|\b4-\d{10}\b|[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}" -CaseSensitive:$false -ErrorAction SilentlyContinue |
    Where-Object {
        $_.Line -notmatch "SR_AUTH_HEADER=Bearer <token>"
    }

if ($findings) {
    Write-Error "Potential secrets, identifiers, or personal information remain in staging folder:`n$($findings | Out-String)"
}

if (Test-Path -LiteralPath $ZipPath) {
    Remove-Item -LiteralPath $ZipPath -Force
}

Compress-Archive -Path (Join-Path $StageRoot "*") -DestinationPath $ZipPath -Force

[PSCustomObject]@{
    SourceRoot = $SourceRoot
    StagingFolder = $StageRoot
    ZipPath = $ZipPath
} | ConvertTo-Json -Depth 3
